//
//  LoginViewController.h
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Api.h"
#import "ASIHTTPRequestDelegate.h"
#import <ShareSDK/ShareSDK.h>
@interface LoginViewController : UIViewController <ASIHTTPRequestDelegate,UIWebViewDelegate, ISSShareViewDelegate>
@property (retain, nonatomic) IBOutlet UITextField *password;
@property (retain, nonatomic) IBOutlet UITextField *username;

- (IBAction)back:(id)sender;
@end
