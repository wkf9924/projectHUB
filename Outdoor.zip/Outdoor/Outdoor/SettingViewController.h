//
//  SettingViewController.h
//  Outdoor
//
//  Created by Robin on 14-1-26.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ShareSDK/ShareSDK.h>
@interface SettingViewController : UIViewController <UITableViewDelegate,UITableViewDataSource,ISSViewDelegate,ISSShareViewDelegate>
@property (retain, nonatomic) IBOutlet UITableView *myTableView;

@end
