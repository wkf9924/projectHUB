//
//  FeedViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ASIHTTPRequestDelegate.h"
#import "Api.h"
@interface FeedViewController : UIViewController <UITextFieldDelegate,UITextViewDelegate,ASIHTTPRequestDelegate>
@property (retain, nonatomic) IBOutlet UITextView *textViewContent;
- (IBAction)back:(id)sender;
- (IBAction)submitFeed:(id)sender;

@end
