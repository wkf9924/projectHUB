//
//  CardShop.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-5.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CardShop : NSObject <NSCoding,NSCopying>
@property (copy, nonatomic) UIImage *image;
@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSString *timeString;
@property (copy, nonatomic) NSString *numString;
@end
