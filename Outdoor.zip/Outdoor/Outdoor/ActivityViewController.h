//
//  ActivityViewController.h
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequestDelegate.h"
#import "STableViewController.h"
#import "EGORefreshTableFooterView.h"
#import "EGORefreshTableHeaderView.h"
#import "ViewPassValueDelegate.h"
@interface ActivityViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,ASIHTTPRequestDelegate,EGORefreshTableHeaderDelegate,ViewPassValueDelegate>

- (IBAction)back:(id)sender;
@property (retain, nonatomic) EGORefreshTableHeaderView *refreshHeaderView;
@property (retain, nonatomic) EGORefreshTableFooterView *refreshFooterView;
@property (retain, nonatomic) IBOutlet UITableView *tableViewActivity;
@property (retain, nonatomic) NSMutableArray *activityArray;//活动列表
@property (assign) int numberPage;//一页显示的条数
@property (assign) int nowPageNum;
@property (retain, nonatomic) IBOutlet UIButton *searchBtn;
@property (assign) BOOL reloading;
@end

