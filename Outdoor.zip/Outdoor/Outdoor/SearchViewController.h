//
//  SearchViewController.h
//  Outdoor
//
//  Created by Robin on 14-2-12.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Api.h"
#import "ViewPassValueDelegate.h"
//#import "ActivityViewController.h"
@interface SearchViewController :UIViewController <ViewPassValueDelegate,ASIHTTPRequestDelegate>
@property (retain, nonatomic) IBOutlet UIScrollView *conditionSC;
@property (retain, nonatomic) IBOutlet UIView *conditionView; //搜索条件的view
@property (retain, nonatomic) IBOutlet UIView *typeView; //类型的view
@property (retain, nonatomic) IBOutlet UIView *hotView; //热门view
@property (retain, nonatomic) IBOutlet UIScrollView *typeSC;
@property (retain, nonatomic) IBOutlet UIScrollView *hotSC;
@property (assign) id<ViewPassValueDelegate> delegeta;
//下面的大view可以动态调整Y轴
@property (retain, nonatomic) IBOutlet UIView *hotGategoryView;

@end
