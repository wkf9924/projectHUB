//
//  ReleaseActivityViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ReleaseActivityViewController.h"
#import "ReleaseActivityCell.h"
#import "Api.h"
#import "ApplyCell.h"
@interface ReleaseActivityViewController ()
@property (retain, nonatomic) NSMutableArray *arrayRelease; //发布活动的数据
@property (assign) int row; //保存点击后row的值
@end

@implementation ReleaseActivityViewController

- (void)dealloc {
    [_arrayRelease release];
    [_tableViewRelease release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _row = -1;
    [self releaseActivity];
    // Do any additional setup after loading the view from its nib.
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
        [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark *********发布活动
- (void)releaseActivity {
    NSString *uidStirng =  STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSString *urlString = [[NSString stringWithFormat:@"%@/%@/%@/%@/%@",SERVER,GETUSER_ACTIVITY,uidStirng,@"1",@"10"] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    MBPHUD_SHOW;
    ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    
    NSMutableDictionary *token = [[Single sharedInstance] getToken];
    [request setRequestHeaders:token];
    
    [request setRequestMethod:@"GET"];
    [request setCompletionBlock:^{
         MBPHUD_HIDDEN;
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.rawResponseData];
        NSLog(@"我发布的活动：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            return;
        }
        
        NSArray *data = [root objectForKey:@"data"];
        if (!ARRAY_IS_NOT_EMPTY(data)) {
//            ALERT_DATA;
            return;
        }
        _tableViewRelease.hidden = NO;
        self.arrayRelease = [NSMutableArray arrayWithArray:data];
        [_tableViewRelease reloadData];

        
    }];
    
    [request setFailedBlock:^{
        MBPHUD_HIDDEN;
        ALERT_DATA;
    }];
    
     [request startAsynchronous];
}
 
#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayRelease.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *customCell = @"customCell";
	ApplyCell *cell = (ApplyCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
	
	if (cell == nil) {
		//如果没有可重用的单元，我们就从nib里面加载一个，
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ApplyCell"
													 owner:self options:nil];
		//迭代nib重的所有对象来查找NewCell类的一个实例
		for (id oneObject in nib) {
			if ([oneObject isKindOfClass:[ApplyCell class]]) {
				cell = (ApplyCell *)oneObject;
			}
		}
         [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	}

    int row = [indexPath row];
    cell.titleString.text = [[_arrayRelease objectAtIndex:row] objectForKey:@"title"];
    NSString *expiration = [[_arrayRelease objectAtIndex:row] objectForKey:@"expiration"];
    NSDate *date = [DateUtil stringToDate:expiration withFormat:@"yyyy-MM-dd HH:mm:ss"];
    cell.timeLab.text = [DateUtil dateToString:date withFormat:@"YYYY-MM-dd"];
    cell.addLab.text = [[_arrayRelease objectAtIndex:row] objectForKey:@"place"];
    [cell.moreBtn addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (void)moreBtnAction:(UIButton *)btn
{
    if (!btn) {
        return;
    }
    ActivityDetailViewController *ad = [[[ActivityDetailViewController alloc] init] autorelease];
    ad.isShowApply = YES;
    ad.isShowCollect = YES;
    ad.tidString = [[_arrayRelease objectAtIndex:btn.tag] objectForKey:@"tid"];
    [self.navigationController pushViewController:ad animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 78.0;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _row = indexPath.row;
     UIActionSheet *alert = [[[UIActionSheet alloc] initWithTitle:nil
                                                        delegate:self
                                               cancelButtonTitle:nil
                                          destructiveButtonTitle:nil
                                                otherButtonTitles:@"报名列表", @"活动详情",@"取消", nil] autorelease];
    [alert showInView:self.view];
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{

    if (buttonIndex == 0) {
        ApplyListVCViewController *ac = [[[ApplyListVCViewController alloc] init] autorelease];
//        ac.arrayApplyList = _arrayRelease;
        ac.tidStirng = [[_arrayRelease objectAtIndex:_row] objectForKey:@"tid"];
        [self.navigationController pushViewController:ac animated:YES];
    }
    if (buttonIndex == 1) {
        ActivityDetailViewController *ad = [[[ActivityDetailViewController alloc] init] autorelease];
        ad.isShowApply = YES;
        ad.isShowCollect = YES;
        ad.tidString = [[_arrayRelease objectAtIndex:_row] objectForKey:@"tid"];
        [self.navigationController pushViewController:ad animated:YES];
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
}

@end
