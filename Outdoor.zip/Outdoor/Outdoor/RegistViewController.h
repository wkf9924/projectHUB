//
//  RegistViewController.h
//  Outdoor
//
//  Created by Robin on 14-2-14.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "Api.h"

@interface RegistViewController : UIViewController <ASIHTTPRequestDelegate>
@property (retain, nonatomic) IBOutlet UITextField *username;
@property (retain, nonatomic) IBOutlet UITextField *password;
@property (retain, nonatomic) IBOutlet UITextField *email;
- (IBAction)registerAction:(id)sender;
- (IBAction)back:(id)sender;

@end
