//
//  ApplyListCell.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-11.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplyListCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titleName;
@property (retain, nonatomic) IBOutlet UILabel *title2;
@property (retain, nonatomic) IBOutlet UILabel *title3;
@property (retain, nonatomic) IBOutlet UILabel *title4;
@property (retain, nonatomic) IBOutlet UILabel *title5;
@property (retain, nonatomic) IBOutlet UIButton *delBtn;

@end
