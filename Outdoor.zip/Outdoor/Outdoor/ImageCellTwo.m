//
//  ImageCellTwo.m
//  Outdoor
//
//  Created by WangKaifeng on 14-3-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ImageCellTwo.h"

@implementation ImageCellTwo

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_imageViewLeft release];
    [_timeLeft release];
    [_prictLeft release];
    [_titleLeft release];
    [_timeRight release];
    [_priceRight release];
    [_imageViewRight release];
    [_titleRight release];
    [_frameImageView release];
    [_defaultImage release];
    [_timeItemImage release];
    [_timeImage release];
    [_priceImage release];
    [_btn_left release];
    [_btn_right release];
    [_labBotton release];
    [_applyLabel release];
    [_applyRightLabel release];
    [_leftView release];
    [_rightView release];
    [_categoryLeft release];
    [_categoryRight release];
    [super dealloc];
}
@end
