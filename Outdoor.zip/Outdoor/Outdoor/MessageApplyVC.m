//
//  MessageApplyVC.m
//  Outdoor
//
//  Created by WangKaifeng on 14-3-20.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "MessageApplyVC.h"
#import "MessageTableViewCell.h"
#import "Api.h"
#import "ChatViewController.h"
@interface MessageApplyVC ()
@property (retain, nonatomic) IBOutlet UITableView *tableViewMessage;

@property (nonatomic,retain) NSMutableArray *activityArray;
@end

@implementation MessageApplyVC
- (void)dealloc {
    [_activityArray release];
    [_tableViewMessage release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
     [self.navigationController setNavigationBarHidden:NO];
    [self.navigationController.navigationBar setBackgroundImage:PNGIMAGE(@"128lv") forBarMetrics:UIBarMetricsDefault];
    //自定义导航栏的"返回"按钮
    
    UIBarButtonItem *backItem = [self customLeftBackButton];
    self.navigationItem.leftBarButtonItem = backItem;
    self.title = @"消息";
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,[UIFont systemFontSize],NSFontAttributeName,nil]];
    
    //我的订阅
    [self subscribeTerm];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)subscribeTerm {
    
    //开始提交数据
    NSString *uid = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSMutableDictionary *token = [[Single sharedInstance] getToken];
    NSString *string = [NSString stringWithFormat:@"%@/%@/%@/%@/%@",SERVER,USER_SUBSCRIPTIONTERM,uid,@"1",@"500"];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:string]];
    [request setRequestHeaders:token];
    [request setRequestMethod:@"GET"];
    MBPHUD_SHOW;
    [request setCompletionBlock:^{
        MBPHUD_HIDDEN;
        int status =request.responseStatusCode;
        NSLog(@"%d",status);
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
        NSString *string = [root objectForKey:@"responseMessage"];
        NSLog(@"状态：%@ \n root:==%@",string,root);
        
        NSInteger success = [[root objectForKey:@"success"] intValue];
        if (success == 1) {
          
            NSArray *arrayData = [root objectForKey:@"data"];
            if (arrayData.count == 0 || !arrayData) {
                return;
            }
            self.activityArray = [NSMutableArray arrayWithArray:arrayData];
            [_tableViewMessage reloadData];
            
            //创建数据库
            [self createDB:_activityArray];
            

        }
        
    }];
    [request  setFailedBlock:^{
        MBPHUD_HIDDEN;
        ALERT_DATA
    }];
    [request startAsynchronous];
}

#pragma mark
#pragma mark  创建活动表
- (void)createDB:(NSMutableArray *)arrayActivity {
    
    SQLiteOperation *sql_opration = [SQLiteOperation shareDB];
    if (![sql_opration isExistsTable:MESSAGE_TABLE_Name]) {
        NSString *creat_table =[NSString stringWithFormat:@"CREATE TABLE %@ (id integer(50),tid integer(50),nodeName varchar(100),title varchar(200),newmessage varchar(500),data varchar(100))",MESSAGE_TABLE_Name];
        [sql_opration dealData:creat_table paramArray:nil];
    }
    
    for (int i=0; i<arrayActivity.count; i++) {
        //取出noteName名字
        NSString *nodeName = [[arrayActivity objectAtIndex:i] objectForKey:@"nodeName"];
        //活动id
        NSString *tid = [[[arrayActivity objectAtIndex:i] objectForKey:@"tid"] stringValue];
        //id
        NSString *activityId = [[[arrayActivity objectAtIndex:i] objectForKey:@"id"] stringValue];
        //活动标题
        NSString *title = [[arrayActivity objectAtIndex:i] objectForKey:@"activityTitle"];
        
        //插入数据
        if (![sql_opration isExistsBook:[activityId integerValue]]) {
            NSArray *paramarray = [NSArray arrayWithObjects:activityId, tid, nodeName, title, nil];
            NSString *creat_book = STRING_FORMAT_INT(@"INSERT INTO %@ (id, tid,nodeName,title) VALUES (?, ?, ?,?)", MESSAGE_TABLE_Name);
            [sql_opration dealData:creat_book paramArray:paramarray];
        }

    }
}


-(UIBarButtonItem*)customLeftBackButton{
    
    UIImage *image=[UIImage imageNamed:@"返回.png"];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame=CGRectMake(15, 20, 25, 44);
    [btn setBackgroundImage:image forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(popself) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[[UIBarButtonItem alloc] initWithCustomView:btn] autorelease];
    return backItem;
}
- (void)popself {
    
    NSString *string = [Single sharedInstance].string;
    if ([string isEqualToString:@"wo"]) {
        NAVIGATION_NUM(3)
    }
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _activityArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"MessageTableViewCell";
    
    MessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"MessageCell" owner:self options:nil];
        
        cell = [array objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSInteger row = [indexPath row];
    NSString *activityTitle = [[_activityArray objectAtIndex:row] objectForKey:@"activityTitle"];
    cell.activityTitle.text = activityTitle;
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChatViewController *cc = [[[ChatViewController alloc] init] autorelease];
    cc.titleString = [[_activityArray objectAtIndex:indexPath.row] objectForKey:@"activityTitle"];
    cc.noteNameStirng = [[_activityArray objectAtIndex:indexPath.row] objectForKey:@"nodeName"];
    ApplicationDelegate.delegate = cc;
    [self.navigationController pushViewController:cc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 77;
}


@end
