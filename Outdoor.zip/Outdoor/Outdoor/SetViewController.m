//
//  SetViewController.m
//  Outdoor
//
//  Created by Robin on 14-1-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "SetViewController.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "Api.h"
#import "HCHTTPClient.h"
#import "SDWebImageManager.h"
#import "SDImageCache.h"
#import "UIImageView+WebCache.h"
#import "SDWebImageManager.h"
#import "SDWebImageDownloader.h"
#import "MBProgressHUD.h"
@interface SetViewController ()

@end

@implementation SetViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    
//    [self performSegueWithIdentifier:@"second" sender:self];  
    //消息传值
//    NSLog(@"send message:%@",firstField.text);
    
    
    
    //页面跳转传值方法二：利用notification
    NSDictionary *dicts = [NSDictionary dictionaryWithObjectsAndKeys:@"one1",@"one",@"two2",@"two",@"three3",@"three", nil];
    NSLog(@"dicts:%@",dicts);
    //注册(第一步)
//    NSNotification *notification  =[NSNotification notificationWithName:@"mynotification" object:@"wangkaifeng"];
//    //发送（第二步）
//    [[NSNotificationCenter defaultCenter] postNotification:notification];
    
    //注册+发送也可以一行完成(等效于以上两行)
    [[NSNotificationCenter defaultCenter] postNotificationName:@"mynotification2" object:dicts];//发送一个字典过去
    

    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    //注册
    [common setObject:@"rrrrrrrr" forKey:@"username"];
    [common setObject:@"rrrrrrrr" forKey:@"password"];
    [common setObject:@"wwwwww@qq.com" forKey:@"email"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,REGISTER_USER];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"POST" parameters:common delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    [MBProgressHUD hideHUDForView:self.navigationController.view animated:YES];
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        
    }
    else {
        
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
   [MBProgressHUD hideHUDForView:self.navigationController.view animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


//#pragma mark   显示商品所有图片
///*
// 方法名称:showProductImageOnSrollView:(NSMutableArray*)productImageArray
// 功能描述: 在请求完成以后显示商品的所有图片
// 传入参数:(NSMutableArray*)productImageArray,传入前请确保数组非空
// 传出参数：N/A
// 返回值:N/A
// */
//- (void) showProductImageOnSrollView:(NSMutableArray*)productImageArray{
//    
//    if (!productImageArray || ![productImageArray isKindOfClass:[NSMutableArray class]]) {
//        return;
//    }
//    
//    //wkf修改
//    [_productImageViewScrollView setContentSize:CGSizeMake(320*productImageArray.count , 320)];//设置ScrollView滚动范围
//    _productImageViewScrollView.clipsToBounds = NO;
//    _productImageViewScrollView.delegate = self;
//    _productImagePageControl.currentPage = 0;
//    for (int i = 0; i < productImageArray.count; i++) {
//        //创建图片
//        //        UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake((228+ 20)*i+10, 0,228, 230)];
//        UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(320*i, 0,320, 320)];
//        //        imageview.tag = BRAND_FAV;
//        [imageview setImageWithURL:[NSURL URLWithString:[productImageArray objectAtIndex:i]] placeholderImage:[UIImage imageNamed:@"详情水印"]];
//        //        [imageview setImageURL:[NSURL URLWithString:[productImageArray objectAtIndex:i]]];
//        imageview.userInteractionEnabled = YES;
//        [_productImageViewScrollView addSubview:imageview];
//        [imageview release];
//    }
//    //设置PageControl页数
//    [_productImagePageControl setNumberOfPages:productImageArray.count];
//    [_mainScrollView bringSubviewToFront:_productImagePageControl];
//    [self.productImageViewScrollView bringSubviewToFront:_stockImageView];
//    
//}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSString *str = @"wwwwwwwwwww";
    UIViewController *seg = segue.destinationViewController;
    [seg setValue:str forKey:@"data"];
    
}


- (IBAction)passValue:(id)sender {
    
    [self performSegueWithIdentifier:@"seg" sender:self];
}
@end
