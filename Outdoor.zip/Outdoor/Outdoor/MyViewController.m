//
//  MyViewController.m
//  Outdoor
//
//  Created by Robin on 14-2-11.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "MyViewController.h"
#import "Api.h"
#import "LoginViewController.h"
#import "ActivityDetailViewController.h"
#import "CollectViewController.h"
#import "LoginViewController.h"
#import "LoginSuccessiewController.h"
#import "AboutViewController.h"
#import "ShoopingCardViewController.h"
#import "testViewController.h"
#import "SetViewController.h"
#import "ActivityViewController.h"
#import "SettingViewController.h"
#import "MessageApplyVC.h"
#define heightY 20
@interface MyViewController ()
@property (nonatomic, retain) NSMutableArray *dataArrC; //row内容
@property (nonatomic, retain) NSMutableArray *dataArrNum; //记录的主键
@property (nonatomic, retain) NSMutableArray *dataSelect; //选中的记录的主键
@property (retain, nonatomic) IBOutlet UIButton *activityButton;
@property (retain, nonatomic) IBOutlet UIButton *shopButton;
@property (retain, nonatomic) IBOutlet UIButton *messageButton;
@property (retain, nonatomic) IBOutlet UIButton *myBtn;

@property (retain, nonatomic) IBOutlet UIButton *driveBtn;
@property (retain, nonatomic) IBOutlet UIButton *collectBtn;
@property (retain, nonatomic) IBOutlet UIButton *setBtn;

- (IBAction)myAction:(id)sender;
- (IBAction)favAction:(id)sender;
- (IBAction)messageAction:(id)sender;
- (IBAction)shoppingAction:(id)sender;
- (IBAction)activityAction:(id)sender;
- (IBAction)setAction:(id)sender;

@end
@implementation MyViewController

- (void)dealloc {
    [_dataArrC release];
    [_dataArrNum release];
    [_dataSelect release];
    [_activityButton release];
    [_shopButton release];
    [_driveBtn release];
    [_collectBtn release];
    [_setBtn release];
    [_myBtn release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        

    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    if (!iPhone5) {
//        //活动
//        _activityButton.frame = CGRectMake(_activityButton.frame.origin.x, _activityButton.frame.origin.y, _activityButton.frame.size.width, _activityButton.frame.size.height+heightY);
//        NSLog(@"%@",_activityButton);
//        //消息
//        _messageButton.frame = CGRectMake(_messageButton.frame.origin.x, _activityButton.frame.origin.y + _activityButton.frame.size.height, _messageButton.frame.size.width, _messageButton.frame.size.height+heightY);
//        //我
//        _myBtn.frame = CGRectMake(_myBtn.frame.origin.x, _messageButton.frame.origin.y + _messageButton.frame.size.height, _myBtn.frame.size.width, _myBtn.frame.size.height+20);
//        //购物车
//        _shopButton.frame = CGRectMake(_shopButton.frame.origin.x, _shopButton.frame.origin.y, _shopButton.frame.size.width, 64.0);
//        //自驾游
//        _driveBtn.frame = CGRectMake(_driveBtn.frame.origin.x, _shopButton.frame.origin.y + _shopButton.frame.size.height, _driveBtn.frame.size.width, _driveBtn.frame.size.height+heightY);
//        //收藏
//        _collectBtn.frame = CGRectMake(_collectBtn.frame.origin.x, _driveBtn.frame.origin.y + _driveBtn.frame.size.height, _collectBtn.frame.size.width, 64.0);
//        //设置
//        _setBtn.frame = CGRectMake(_setBtn.frame.origin.x, _collectBtn.frame.origin.y + _collectBtn.frame.size.height-2, _setBtn.frame.size.width, _setBtn.frame.size.height+heightY);
//        
//
//    }
   	// Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)myAction:(id)sender {
    
   
    if (![Util isLogin]) {
        LoginViewController *login = [[LoginViewController alloc] initWithNibName:@"LoginView" bundle:nil];
        [self.navigationController pushViewController:login animated:YES];
        [Single sharedInstance].string = @"wo";
    } else {
         [Single sharedInstance].string = @"";
        LoginSuccessiewController *loginSuccess = [[LoginSuccessiewController alloc] initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:loginSuccess animated:YES];
    }
}

- (IBAction)favAction:(id)sender {
    
    
    if (![Util isLogin]) {
        LoginViewController *login = [[[LoginViewController alloc] initWithNibName:nil bundle:nil]autorelease];
        [Single sharedInstance].string = @"";
        [self.navigationController pushViewController:login animated:YES];
        return;
    }
    [Single sharedInstance].string = @"shouCang";
    CollectViewController *collectView = [[CollectViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:collectView animated:YES];
}

- (IBAction)messageAction:(id)sender {

    if (![Util isLogin]) {
        LoginViewController *login = [[[LoginViewController alloc] initWithNibName:nil bundle:nil]autorelease];
        [Single sharedInstance].string = @"";
        [self.navigationController pushViewController:login animated:YES];
        return;

    }
    [Single sharedInstance].string = @"xiaoxi";
    MessageApplyVC *ma = [[[MessageApplyVC alloc] init] autorelease];
    [self.navigationController pushViewController:ma animated:YES];
//    ChatViewController *newInfo = [[[ChatViewController alloc] init] autorelease];
//    [self presentViewController:newInfo animated:YES completion:NULL];
}

- (IBAction)shoppingAction:(id)sender
{
    
    if ([Util isLogin]) {
        ShoopingCardViewController *shopingCard = [[[ShoopingCardViewController alloc] init] autorelease];
        [Single sharedInstance].string = @"";
        [self.navigationController pushViewController:shopingCard animated:YES];
        return;
    }
    [Single sharedInstance].string = @"shop";
    LOGIN_VIEWCONTROLLER;
}
- (IBAction)buttonAction:(id)sender {
//
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:[NSBundle mainBundle]];
    testViewController *mainViewController = (testViewController*)[storyboard instantiateViewControllerWithIdentifier:@"testview"];
//    [self.storyboard instantiateViewControllerWithIdentifier:@"testview"];
//    [self presentViewController:mainViewController animated:YES completion:nil];
    [self.navigationController pushViewController:mainViewController animated:YES];
}

- (IBAction)activityAction:(id)sender {
    ActivityViewController *ac = [[[ActivityViewController alloc] init] autorelease];
    [self.navigationController pushViewController:ac animated:YES];
}

- (IBAction)setAction:(id)sender {
    SettingViewController *st = [[[SettingViewController alloc] init] autorelease];
    [self.navigationController pushViewController:st animated:YES];
}
@end
