//
//  CollectViewController.m
//  Outdoor
//
//  Created by Robin on 14-2-13.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "CollectViewController.h"
#import "CollectCell.h"
#import "ActivityDetailViewController.h"
#import "DemoTableFooterView.h"
#import "DemoTableHeaderView.h"
#import "EGORefreshTableFooterView.h"
#import "EGORefreshTableHeaderView.h"

#define PAGE_NUM 20

@interface CollectViewController ()
@property (retain, nonatomic) NSMutableArray *arrayCollect; //收藏

@property (retain, nonatomic) EGORefreshTableHeaderView *refreshHeaderView;

@property (retain, nonatomic) EGORefreshTableFooterView *refreshFooterView;

@property (assign) BOOL reloading;

@property (assign) int nowPageNum;

@property (assign) int page;

@property (retain, nonatomic) IBOutlet UITableView *tableViewCollect;

- (IBAction)back:(id)sender;

- (IBAction)editTableView:(id)sender;

@end

@implementation CollectViewController

- (void)dealloc {
    [_refreshFooterView release];
    [_refreshHeaderView release];
    [_arrayCollect release];
    [_tableViewCollect release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.arrayCollect = [NSMutableArray array];

    }
    return self;
}
SWIPE_RIGHT_MONTH;
- (void)viewDidLoad
{
    [super viewDidLoad];
    SWIPE_RIGHT;
    _nowPageNum = 1;
    [self favoriteList:_nowPageNum num:PAGE_NUM];
    
}

- (void)reloadDataAction {
    NSLog(@"加载数据了");

}
- (void)doneWithView:(MJRefreshBaseView *)refreshView
{
    // 刷新表格
    [self.tableViewCollect reloadData];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
    [refreshView endRefreshing];
}
//收藏列表
- (void)favoriteList:(int)page num:(int)number {
    
    NSString *numpage = [NSString stringWithFormat:@"%d",number];
    NSString *pgnum = [NSString stringWithFormat:@"%d",page];
    NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@/%@",SERVER,ACTIVITY_FAVORITE_LIST,uidStirng,pgnum,numpage];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    httpClient.pageNumber = page;
    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
    
}
- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
    NSArray *dataArray = [root objectForKey:@"data"];
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        if (!ARRAY_IS_NOT_EMPTY(dataArray)) {
            
            [self loadOk];
            return;
        }
         ALERT_DATA;
        [self loadOk];
        return;
    }

    NSMutableArray *arrayActivity = [NSMutableArray arrayWithArray:dataArray];
    
    //判断是下拉还是上提
    if (request.tag == REQUEST_PAGE_ONE) {
        MBPHUD_HIDDEN;
        //下拉就会清除之前的缓存数据
        [self.arrayCollect removeAllObjects];
        self.arrayCollect = arrayActivity;
    }
    else{
        
        MBPHUD_HIDDEN;
        [self.arrayCollect addObjectsFromArray:arrayActivity];
    }
    
    [self.tableViewCollect reloadData];
    
    CGRect  _newFrame = CGRectMake(0.0f, self.tableViewCollect.contentSize.height,self.view.frame.size.width,self.tableViewCollect.bounds.size.height);
    if (self.arrayCollect.count > 20) {
        [self createHeaderView];
        [self createFooterView];
    }
    _refreshFooterView.frame = _newFrame;
    [self loadOk];
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
    ALERT_DATA;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayCollect.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *customCell = @"customCell";
    CollectCell *cell = (CollectCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
    if (cell == nil) {
        //如果没有可重用的单元，我们就从nib里面加载一个，
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CollectCell" owner:self options:nil];
        //迭代nib重的所有对象来查找NewCell类的一个实例
        for (id oneObject in nib) {
            if ([oneObject isKindOfClass:[CollectCell class]]) {
                cell = (CollectCell *)oneObject;
            }
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    
    cell.titleCollect.text = [[_arrayCollect objectAtIndex:indexPath.row] objectForKey:@"title"];
    if ([[_arrayCollect objectAtIndex:indexPath.row] objectForKey:@"place"]) {
        cell.priceLabel.text = [NSString stringWithFormat:@"地点:%@",[[_arrayCollect objectAtIndex:indexPath.row] objectForKey:@"place"]];
    }
    
    
    
    //时间日期
    double timeDouble = [[[[_arrayCollect objectAtIndex:indexPath.row] objectForKey:@"starttimefrom"] stringValue] doubleValue];
    NSDate* date= [NSDate dateWithTimeIntervalSince1970:timeDouble];
    NSString *refundString = [DateUtil dateToString:date withFormat:@"MM月dd日 HH:mm"];
    cell.timeLabel.text = [NSString stringWithFormat:@"截止时间:%@",refundString];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //其他单元格事件
    ActivityDetailViewController *ad  = [[[ActivityDetailViewController alloc] init] autorelease];
    ad.isShowCollect = YES;
    ad.tidString = [[_arrayCollect objectAtIndex:indexPath.row] objectForKey:@"tid"];
    [self.navigationController pushViewController:ad animated:YES];
    
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{

    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        UIAlertView *alert = [[UIAlertView alloc ]initWithTitle:@"提示" message:@"您确定要删除么?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定",nil];
        alert.tag = indexPath.row + 2000;
        [alert show];
        [alert release];
        
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}



- (IBAction)back:(id)sender {
    
    NSString *string = [Single sharedInstance].string;
    if ([string isEqualToString:@"wo"]) {
        NAVIGATION_NUM(3)
    }
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark
#pragma mark 删除收藏
-(void)deleteExecute:(int)indexNumber
{
    NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSString *tidString = [[[_arrayCollect objectAtIndex:indexNumber] objectForKey:@"tid"] stringValue];
    NSString *stringInfo = [NSString stringWithFormat:@"%d",indexNumber];
    NSDictionary *dic = @{@"tag": stringInfo};
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@",SERVER,ACTIVITY_DELFAVORITE,uidStirng,tidString];
        HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestCollectDelateFinished:) onFailure:@selector(requestDelateFailed:) userInfo:dic];
    MBPHUD_SHOW;

}
- (void)requestCollectDelateFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    ASIFormDataRequest *requestForm=(ASIFormDataRequest*)request;
    NSDictionary *root = [JSONFunction jsonObjectWithData:request.rawResponseData];
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        [[iToast makeToast:@"删除失败"] show];
        return;
    }
    
    //执行删除操作
    NSDictionary *userinfoDic = requestForm.userInfo;
    int tag = [[userinfoDic objectForKey:@"tag"]  intValue];
    [self.arrayCollect removeObjectAtIndex:tag];
    [self.tableViewCollect deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:tag inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
}

- (void)requestDelateFailed:(ASIHTTPRequest *)request
{
    
    MBPHUD_HIDDEN;
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [self deleteExecute:alertView.tag - 2000];
    }
}


- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 90;
}


- (IBAction)editTableView:(id)sender {
    
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        [_arrayShopping removeObjectAtIndex:indexPath.row];
//        // Delete the row from the data source.
//        [_tableViewShopping deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
//        
//    }
//    else if (editingStyle == UITableViewCellEditingStyleInsert) {
//        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
//    }
//    UITableViewCellEditingStyle
    UIButton *button = (UIButton *) [self.view viewWithTag:100];
    NSLog(@"butontag:=%@",button);

    if (_tableViewCollect.editing == YES) {
        _tableViewCollect.editing = NO;
        [button setTitle:@"编辑" forState:0];
    }
    else {
        _tableViewCollect.editing = YES;
         [button setTitle:@"取消" forState:0];
    }
}

#pragma mark - EGORefreshTableHeader
-(void)createHeaderView{
    if (_refreshHeaderView && [_refreshFooterView superview]) {
        [_refreshHeaderView removeFromSuperview];
    }
	_refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame: CGRectMake(0.0f, 0.0f - self.view.bounds.size.height,self.view.frame.size.width, self.view.bounds.size.height)];
    _refreshHeaderView.backgroundColor = [UIColor clearColor];
    _refreshHeaderView.delegate = self;
	[self.tableViewCollect  addSubview:_refreshHeaderView];
    [_refreshHeaderView refreshLastUpdatedDate];
    
}

#pragma mark - EGORefreshTableFooter
-(void)createFooterView{
    if (_refreshFooterView && [_refreshFooterView superview]) {
        [_refreshFooterView removeFromSuperview];
    }
    
	if (self.tableViewCollect.contentSize.height>=self.view.bounds.size.height){
        _refreshFooterView = [[EGORefreshTableFooterView alloc] initWithFrame:CGRectMake(0.0f, self.tableViewCollect.frame.size.height, self.tableViewCollect.frame.size.width, self.tableViewCollect.bounds.size.height)];
        _refreshFooterView.backgroundColor  = [UIColor clearColor];
        _refreshFooterView.delegate = self;
        
        [self.tableViewCollect addSubview:_refreshFooterView];
        
        [_refreshFooterView refreshLastUpdatedDate];
        
        CGRect  _newFrame =  CGRectMake(0.0f, self.tableViewCollect.frame.size.height,self.view.frame.size.width, self.tableViewCollect.bounds.size.height);
        _refreshFooterView.frame = _newFrame;
    }
}
#pragma mark - EGORefreshTableDelegate
- (void)egoRefreshTableHeaderDidTriggerRefresh:(UIView*)view
{
    //顶部数据刷新
    if ([view isEqual:_refreshHeaderView]) {
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
        [self favoriteList:1 num:PAGE_NUM];
        _nowPageNum =1;
    }
    //底部数据刷新
    else if([view isEqual:_refreshFooterView]) {
        _reloading = NO;
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
        _nowPageNum++;
        [self favoriteList:_nowPageNum num:PAGE_NUM];
    }
}
-(void)loadOk
{
    _reloading = NO;
    [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
    [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewCollect];
    
}
- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(UIView*)view
{
    return _reloading;
}


#pragma mark - UIScrollView delegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    [_refreshFooterView egoRefreshScrollViewDidScroll:scrollView];
    
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	[_refreshFooterView egoRefreshScrollViewDidEndDragging:scrollView];
}

@end
