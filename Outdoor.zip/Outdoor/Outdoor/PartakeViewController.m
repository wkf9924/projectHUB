//
//  PartakeViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "PartakeViewController.h"
#import "ApplyCell.h"
#import "RecordCell.h"
#import "ReleaseActivityCell.h"
#import "Api.h"
#import "ActivityDetailViewController.h"
@interface PartakeViewController ()
@property (assign) int butTag;
@property (retain, nonatomic) NSMutableArray *arrParticipate;//参加活动数据
@property (retain, nonatomic) IBOutlet UIImageView *imageViewApply;

//参与的活动
- (IBAction)applyButAction:(id)sender;
- (IBAction)recordAction:(id)sender;
@end

@implementation PartakeViewController
- (void)dealloc {
    [_arrParticipate release];
    [_tableViewPartake release];
    [_butApply release];
    [_butRecord release];
    [_mainView release];
    [_imageViewApply release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _butTag = -1;
    }
    return self;
}
#pragma mark
#pragma mark 活动记录
- (void)recordDataAction {
    
    NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:uidStirng forKey:@"uid"];
    [common setObject:@"1" forKey:@"page"];
    [common setObject:@"500" forKey:@"pagesize"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTIVITY_HISTORY_CURRENT];
    
    [DataRequest dataWithDic:common andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSLog(@"参与的活动：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            
            return;
        }
        
        NSArray *data = [root objectForKey:@"data"];
        if (!ARRAY_IS_NOT_EMPTY(data)) {
            return;
        }
        _tableViewPartake.hidden = NO;
        self.arrParticipate = [NSMutableArray arrayWithArray:data];
        [_tableViewPartake reloadData];
        
    }];
    
}

#pragma mark
#pragma mark 报名的活动
- (void)takePartAction {
    
    NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:uidStirng forKey:@"uid"];
    [common setObject:@"1" forKey:@"page"];
    [common setObject:@"500" forKey:@"pagesize"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTIVITY_CURRENT_USER];
    
    MBPHUD_SHOW;
    [DataRequest dataWithDic:common andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        
        MBPHUD_HIDDEN;
        NSLog(@"requestStr:%@",requestStr);
        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSLog(@"参与的活动：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            
            return;
        }
        
        NSArray *data = [root objectForKey:@"data"];
        if (!ARRAY_IS_NOT_EMPTY(data)) {
            return;
        }
        _tableViewPartake.hidden = NO;
        self.arrParticipate = [NSMutableArray arrayWithArray:data];
        [_tableViewPartake reloadData];

    }];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    SWIPE_RIGHT;
    _butTag = 100;
    //报名的活动
    [self takePartAction];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    NSLog(@"viewDidDisappear");
}
SWIPE_RIGHT_MONTH;
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrParticipate.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int row = indexPath.row;
    NSLog(@"row====%d",row);
    if (_butTag == 100) {
        static NSString *customCell = @"ApplyCell";
        ApplyCell *cell = (ApplyCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
        
        if (cell == nil) {
            //如果没有可重用的单元，我们就从nib里面加载一个，
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ApplyCell"
                                                         owner:self options:nil];
            //迭代nib重的所有对象来查找NewCell类的一个实例
            for (id oneObject in nib) {
                if ([oneObject isKindOfClass:[ApplyCell class]]) {
                    cell = (ApplyCell *)oneObject;
                }
            }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        }
     
       
        //标题
        cell.titleString.text = [[_arrParticipate objectAtIndex:row] objectForKey:@"title"];
        //地址
        cell.addLab.text = [[_arrParticipate objectAtIndex:row] objectForKey:@"place"];
        [cell.moreBtn setTag:indexPath.row];
        [cell.moreBtn addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        //时间日期
        double timeDouble = [[[[_arrParticipate objectAtIndex:row] objectForKey:@"starttimefrom"] stringValue] doubleValue];
        NSDate* date= [NSDate dateWithTimeIntervalSince1970:timeDouble];
        NSString *refundString = [DateUtil dateToString:date withFormat:@"MM月dd日 HH:mm"];
        cell.timeLab.text = [NSString stringWithFormat:@"%@",refundString];
        
        return cell;
        
    } else {
        static NSString *customCell = @"RecordCell";
        RecordCell *cell = (RecordCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
        
        if (cell == nil) {
            //如果没有可重用的单元，我们就从nib里面加载一个，
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RecordCell"
                                                         owner:self options:nil];
            //迭代nib重的所有对象来查找NewCell类的一个实例
            for (id oneObject in nib) {
                if ([oneObject isKindOfClass:[RecordCell class]]) {
                    cell = (RecordCell *)oneObject;
                }
            }
            
            [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        }
        
        cell.titleLab.text = [[_arrParticipate objectAtIndex:row] objectForKey:@"title"];
        cell.addLab.text = [[_arrParticipate objectAtIndex:row] objectForKey:@"place"];
        //时间日期
        double timeDouble = [[[[_arrParticipate objectAtIndex:indexPath.row] objectForKey:@"starttimefrom"] stringValue] doubleValue];
        NSDate* date= [NSDate dateWithTimeIntervalSince1970:timeDouble];
        NSString *refundString = [DateUtil dateToString:date withFormat:@"MM月dd日"];
        cell.dateLab.text = [NSString stringWithFormat:@"%@",refundString];
        if ([[_arrParticipate objectAtIndex:row] objectForKey:@"sponsor"]) {
            cell.userLab.text = [NSString stringWithFormat:@"领队人:%@", [[_arrParticipate objectAtIndex:row] objectForKey:@"sponsor"]];
        }
        
        return cell;
    }
    
}

- (void)moreBtnAction:(UIButton *)btn
{
    if (!btn) {
        return;
    }
    ActivityDetailViewController *ad = [[[ActivityDetailViewController alloc] init] autorelease];
    ad.isShowCollect = YES;
    ad.isShowApply = YES;
    ad.tidString = [[_arrParticipate objectAtIndex:btn.tag] objectForKey:@"tid"];
    [self.navigationController pushViewController:ad animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_butTag == 100) {
        
        NSLog(@"记录");
        return 75;
    }
    return 94;
    NSLog(@"报名");
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
}


- (IBAction)applyButAction:(id)sender {
    if (_arrParticipate) {
        [_arrParticipate removeAllObjects];
    }
    _butTag = 100;
    _imageViewApply.image = PNGIMAGE(@"报名的活动");
    [self takePartAction];
    [_tableViewPartake reloadData];
}

- (IBAction)recordAction:(id)sender {
    if (_arrParticipate) {
        [_arrParticipate removeAllObjects];
    }
    _butTag = 200;
    _imageViewApply.image = PNGIMAGE(@"活动记录");
    [self recordDataAction];
    [_tableViewPartake reloadData];
}
@end
