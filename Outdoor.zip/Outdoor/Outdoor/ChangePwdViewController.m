//
//  ChangePwdViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ChangePwdViewController.h"
#import "Api.h"
@interface ChangePwdViewController ()

@end

@implementation ChangePwdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)requestResetPwd {
    
}

- (IBAction)updateOK:(id)sender {
    
//    [self requestResetPwd];//找回密码接口
    
    NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:uidStirng forKey:@"uid"];
    [common setObject:_oldTextField.text forKey:@"oldpassword"];
    [common setObject:_newTextField.text forKey:@"newpassword"];
    [common setObject:@"update" forKey:@"opt_type"];

    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,UPDATE_PASSWORD];
    MBPHUD_SHOW;
    [DataRequest dataWithDic:common andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        
        MBPHUD_HIDDEN;
        NSLog(@"requestStr:%@", requestStr);
        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSLog(@"修改密码：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            
            return;
        }
        
        NSArray *data = [root objectForKey:@"data"];
        if (!ARRAY_IS_NOT_EMPTY(data)) {
            return;
        }
        
    }];
}

- (void)dealloc {
    [_oldTextField release];
    [_newTextField release];
    [_okTextField release];
    [super dealloc];
}
@end
