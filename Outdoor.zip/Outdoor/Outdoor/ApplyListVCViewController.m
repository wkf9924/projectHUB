//
//  ApplyListVCViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-3-6.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ApplyListVCViewController.h"
#import "ReleaseActivityCell.h"
#import "ApplyListCell.h"
#import "Api.h"
@interface ApplyListVCViewController ()
@property (retain, nonatomic) IBOutlet UITableView *tableViewApply;
- (IBAction)back:(id)sender;
@property (retain, nonatomic) IBOutlet UISegmentedControl *segmented;
- (IBAction)segment:(id)sender;

@end

@implementation ApplyListVCViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.arrayApplyList = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //审核活动的
    [self applyListAction:@"0"];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
  
}

- (void)dealloc {
    [_tidStirng release];
    [_tableViewApply release];
    [_arrayApplyList release];
    [_segmented release];
    [super dealloc];
}
- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

//默认查询未审核的活动
-(void)applyListAction:(NSString *)string {
    
    NSString *urlString = [[NSString stringWithFormat:@"%@/%@/%@/%@/%@/%@", SERVER,APPLEY_USER,self.tidStirng, string, @"1",@"20"] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
     ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    [request setRequestMethod:@"GET"];
    NSMutableDictionary *dicToken = [[Single sharedInstance] getToken];
    [request setRequestHeaders:dicToken];
    
    MBPHUD_SHOW;
    [request setCompletionBlock:^{
        
        MBPHUD_HIDDEN;
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
        NSMutableArray *dataArray = [root objectForKey:@"data"];
               NSString *successString = [[root objectForKey:@"success"] stringValue];

        if (![successString isEqualToString:@"1"]) {
            return;
        }
        if (!ARRAY_IS_NOT_EMPTY(dataArray)) {
            return;
        }

        
        [self.arrayApplyList addObjectsFromArray:dataArray];
        [_tableViewApply reloadData];
        
    }];
    
    [request setFailedBlock:^{
        MBPHUD_HIDDEN;
        ALERT_DATA
    }];
    
    [request startAsynchronous];
    
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayApplyList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *identifier = @"ApplyListCell";
    ApplyListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil) {
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"ApplyListCell" owner:self options:nil];
        cell = [array objectAtIndex:0];
    }
    if (_segmented.selectedSegmentIndex == 1) {
        cell.delBtn.hidden = YES;
    } else {
        cell.delBtn.hidden = NO;
    }
    NSInteger row = [indexPath row];
    
    //name
    cell.titleName.text = [NSString stringWithFormat:@"姓名：%@",[[_arrayApplyList objectAtIndex:row] objectForKey:@"username"]];
    
    //电话
    NSString *mobileStr = [[_arrayApplyList objectAtIndex:row] objectForKey:@"mobile"];
    if (![mobileStr isEqualToString:@""]) {
        cell.title2.text = [NSString stringWithFormat:@"联系电话：%@", mobileStr];
    }
    else {
        cell.title2.text = @"联系电话：";
    }

    
    //邮箱
    NSString *emailStr = [[_arrayApplyList objectAtIndex:row] objectForKey:@"email"];
    if (![emailStr isEqualToString:@""]) {
        cell.title3.text = [NSString stringWithFormat:@"邮箱：%@",emailStr];
    }
    cell.delBtn.tag = row + TagNum;
    [cell.delBtn addTarget:self action:@selector(checkBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}



- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return NO;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_segmented.selectedSegmentIndex == 0) {
        return 126.0;
    }
    
    return 91;
    
}

//提交审核
- (void)checkBtnAction: (UIButton *)sender{

    NSInteger numTag = sender.tag - TagNum;
    //applyid
    NSString *tid = [[_arrayApplyList objectAtIndex:numTag] objectForKey:@"applyid"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@",SERVER,REVIEWAPPLYACTIVITY,tid,@"1"];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    NSMutableDictionary *token = [[Single sharedInstance] getToken];
    [request setRequestHeaders:token];
    [request setRequestMethod:@"GET"];
    MBPHUD_SHOW;
    [request setCompletionBlock:^{
        MBPHUD_HIDDEN;
        int status =request.responseStatusCode;
        NSLog(@"%d",status);
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
        NSString *string = [root objectForKey:@"responseMessage"];
        NSLog(@"状态：%@ \n root:==%@",string,root);
        
    }];
    [request  setFailedBlock:^{
        MBPHUD_HIDDEN;
    }];
    [request startAsynchronous];
    

}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        NSInteger tag = alertView.tag - TagNum;
        [self.arrayApplyList removeObjectAtIndex:tag];
        [self.tableViewApply deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:tag inSection:0]] withRowAnimation:UITableViewRowAnimationMiddle];
        [_tableViewApply reloadData];
    }
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (IBAction)segment:(id)sender {
    if (_segmented.selectedSegmentIndex == 0) {
        //applyid
        [self applyListAction:@"0"];
        
    }
    if (_segmented.selectedSegmentIndex == 1) {
        [self applyListAction:@"1"];

    }
    
    if (_arrayApplyList.count > 0) {
        [_arrayApplyList removeAllObjects];
        [_tableViewApply reloadData];
    }
}


@end
