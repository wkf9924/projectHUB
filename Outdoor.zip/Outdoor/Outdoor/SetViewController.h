//
//  SetViewController.h
//  Outdoor
//
//  Created by Robin on 14-1-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "ViewPassValueDelegate.h"


@interface SetViewController : UIViewController <ASIHTTPRequestDelegate>

@property (assign) id <ViewPassValueDelegate> *delegate;
- (IBAction)passValue:(id)sender;
@end
