//
//  SetCell.h
//  Outdoor
//
//  Created by Robin on 14-1-26.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;
@property (retain, nonatomic) IBOutlet UIButton *moreInfo;
@property (retain, nonatomic) IBOutlet UIImageView *selectImageView;
@property (retain, nonatomic) IBOutlet UIImageView *imageViewInfo;

@end
