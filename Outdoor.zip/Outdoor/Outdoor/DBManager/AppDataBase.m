//
//  AppDataBase.m
//  eDiancheDriver
//
//  Created by Mars on 13-1-29.
//  Copyright (c) 2013年 SKTLab. All rights reserved.
//

#import "AppDataBase.h"

#define TABLE_NAME_BOOK_HISTORY @"bookHistory"
#define TABLE_NAME_SYSTEM_MESSAGE @"systemMessage"

@implementation AppDataBase

- (id) initDb {
    
    self = [super init];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    NSString *dbPath = [documentDirectory stringByAppendingPathComponent:@"dataBase.db"];
    FMDatabase *fmdb = [FMDatabase databaseWithPath:dbPath];
    if (![fmdb open]) {
        DLog(@"Could not open db.");
        return nil;
    }
    self.myDB = fmdb;
    
    self.dateFormatter = [[NSDateFormatter alloc] init];
    [self.dateFormatter setLocale:[NSLocale systemLocale]];
    [self.dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    
    [self prepareTables];

    return self;
}

- (void) prepareTables {
    
//    if (![self.myDB tableExists:TABLE_NAME_BOOK_HISTORY]) {
//        NSString *sql = [self SQL:@"CREATE TABLE IF NOT EXISTS '%@' ('index' INTEGER PRIMARY KEY AUTOINCREMENT, 'passengerName' TEXT , 'passengerContact' TEXT , 'takePlace' TEXT ,'takeTime' TEXT );" inTable:TABLE_NAME_BOOK_HISTORY];
//        DLog(@"%@",sql);
//        BOOL result = [self.myDB executeUpdate:sql];
//        if (result) {
//            DLog(@"create success");
//        }
//    }
    
    if (![self.myDB tableExists:TABLE_NAME_SYSTEM_MESSAGE]) {
        NSString *sql = [self SQL:@"CREATE TABLE IF NOT EXISTS '%@' ('index' INTEGER PRIMARY KEY AUTOINCREMENT, 'messageTitle' TEXT, 'systemMessage' TEXT, 'messageTime' TEXT );" inTable:TABLE_NAME_SYSTEM_MESSAGE];
        DLog(@"%@",sql);
        BOOL result = [self.myDB executeUpdate:sql];
        if (result) {
            DLog(@"create success");
        }
    }

    [self.myDB close];
}

- (NSString *)SQL:(NSString *)sql inTable:(NSString *)table{
    return [NSString stringWithFormat:sql,table];
}

//- (BOOL) insterOrUpdateWithBookingHistory:(BookingHistory *)bookingHistory{
//    
//    [self.myDB open];
//    [self.myDB beginTransaction];
//    NSString * insertSql = [self SQL:@"REPLACE INTO %@ ('passengerName', 'passengerContact', 'takePlace', 'takeTime') VALUES (?, ?, ?, ?)" inTable:TABLE_NAME_BOOK_HISTORY];
//    BOOL isSuccess = [self.myDB executeUpdate:insertSql, bookingHistory.passengerName, bookingHistory.passengerContact, bookingHistory.takePlace, bookingHistory.takeTime];
//    [self.myDB commit];
//    [self.myDB close];
//    
//    return isSuccess;
//}

- (BOOL) deleteBookingHistory:(NSString *)index{
    
    [self.myDB open];
    [self.myDB beginTransaction];
    NSString * deleteSql = [self SQL:@"DELETE FROM %@ WHERE \"index\" = ? " inTable:TABLE_NAME_BOOK_HISTORY];
    BOOL isSuccess = [self.myDB executeUpdate:deleteSql,index];
    [self.myDB commit];
    [self.myDB close];
    
    return isSuccess;
}

- (BOOL) deleteAllBookingHistory{
    
    [self.myDB open];
    [self.myDB beginTransaction];
    NSString * deleteSql = [self SQL:@"DELETE FROM %@" inTable:TABLE_NAME_BOOK_HISTORY];
    BOOL isSuccess = [self.myDB executeUpdate:deleteSql];
    [self.myDB commit];
    [self.myDB close];
    
    return isSuccess;
}

//- (NSMutableArray*) getAllBookingHistory{
//    
//    NSMutableArray *reslute = [[NSMutableArray alloc]initWithCapacity:0];
//    
//    NSMutableString *sql = [NSMutableString stringWithString:[self SQL:@"SELECT * FROM %@ ORDER BY taketime DESC" inTable:TABLE_NAME_BOOK_HISTORY]];
//    
//    [self.myDB open];
//    FMResultSet *rs = [self.myDB executeQuery:sql];
//    
//    while ([rs next]) {
//        BookingHistory *bookingHistory = [[BookingHistory alloc]init];
//        bookingHistory.index = [rs stringForColumn:@"index"];
//        bookingHistory.passengerName = [rs stringForColumn:@"passengerName"];
//        bookingHistory.passengerContact = [rs stringForColumn:@"passengerContact"];
//        bookingHistory.takePlace = [rs stringForColumn:@"takePlace"];
//        bookingHistory.takeTime = [rs stringForColumn:@"takeTime"];
//        [reslute addObject:bookingHistory];
//    }
//    [rs close];
//    [self.myDB close];
//    
//    return reslute;
//}
//
//
//- (BOOL) insterSystemMessageWithSystemMessage:(SystemMessage *)systemMessage {
//    
//    [self.myDB open];
//    [self.myDB beginTransaction];
//    NSString * insertSql = [self SQL:@"REPLACE INTO %@ ('messageTitle', 'systemMessage', 'messageTime') VALUES (?, ?, ?)" inTable:TABLE_NAME_SYSTEM_MESSAGE];
//    BOOL isSuccess = [self.myDB executeUpdate:insertSql, systemMessage.messageTitle, systemMessage.systemMessage, systemMessage.messageTime];
//    [self.myDB commit];
//    [self.myDB close];
//    
//    return isSuccess;
//}

- (BOOL) deleteSystemMessageWithSystemMessageID:(NSString *) systemID {
    [self.myDB open];
    [self.myDB beginTransaction];
    NSString * deleteSql = [self SQL:@"DELETE FROM %@ WHERE \"index\" = ? " inTable:TABLE_NAME_SYSTEM_MESSAGE];
    BOOL isSuccess = [self.myDB executeUpdate:deleteSql,systemID];
    [self.myDB commit];
    [self.myDB close];
    
    return isSuccess;
}

- (BOOL) deleteAllSystemMessage {
    [self.myDB open];
    [self.myDB beginTransaction];
    NSString * deleteSql = [self SQL:@"DELETE FROM %@" inTable:TABLE_NAME_SYSTEM_MESSAGE];
    BOOL isSuccess = [self.myDB executeUpdate:deleteSql];
    [self.myDB commit];
    [self.myDB close];
    
    return isSuccess;
}

//- (NSMutableArray *) getAllSystemMessage {
//    NSMutableArray *reslute = [[NSMutableArray alloc]initWithCapacity:0];
//    
//    NSMutableString *sql = [NSMutableString stringWithString:[self SQL:@"SELECT * FROM %@ ORDER BY messageTime DESC" inTable:TABLE_NAME_SYSTEM_MESSAGE]];
//    
//    [self.myDB open];
//    FMResultSet *rs = [self.myDB executeQuery:sql];
//    
//    while ([rs next]) {
//        SystemMessage *systemMessage = [[SystemMessage alloc]init];
//        systemMessage.index = [rs stringForColumn:@"index"];
//        systemMessage.systemMessage = [rs stringForColumn:@"systemMessage"];
//        systemMessage.messageTitle = [rs stringForColumn:@"messageTitle"];
//        systemMessage.messageTime = [rs stringForColumn:@"messageTime"];
//        [reslute addObject:systemMessage];
//    }
//    [rs close];
//    [self.myDB close];
//    
//    return reslute;
//}

@end
