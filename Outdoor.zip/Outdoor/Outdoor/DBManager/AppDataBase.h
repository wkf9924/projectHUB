//
//  AppDataBase.h
//  eDiancheDriver
//
//  Created by Mars on 13-1-29.
//  Copyright (c) 2013年 SKTLab. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
//#import "SystemMessage.h"
//#import "BookingHistory.h"
@interface AppDataBase : NSObject

@property (nonatomic, strong) FMDatabase *myDB;
@property (nonatomic, strong) NSDateFormatter *dateFormatter;
- (id) initDb;

//- (BOOL) insterOrUpdateWithBookingHistory:(BookingHistory *)bookingHistory;

- (BOOL) deleteBookingHistory:(NSString *)index;

- (BOOL) deleteAllBookingHistory;

//- (NSMutableArray*) getAllBookingHistory;


//- (BOOL) insterSystemMessageWithSystemMessage:(SystemMessage *)systemMessage;

- (BOOL) deleteSystemMessageWithSystemMessageID:(NSString *) systemID;

- (BOOL) deleteAllSystemMessage;

//- (NSMutableArray *) getAllSystemMessage;

@end
