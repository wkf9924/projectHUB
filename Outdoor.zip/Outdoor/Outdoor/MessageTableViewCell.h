//
//  MessageTableViewCell.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-20.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageTableViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *activityTitle;
@property (retain, nonatomic) IBOutlet UILabel *messageTitle;

@end
