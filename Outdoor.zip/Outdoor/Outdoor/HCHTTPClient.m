//
//  HCHTTPClient.m
//  HC
//
//  Created by Sylar on 13-10-18.
//  Copyright (c) 2013年 Sylar. All rights reserved.
//

#import "HCHTTPClient.h"
#import "Api.h"

#define PHONE_TYPE @"1"
//static HCHTTPClient *instance = nil;

@implementation HCHTTPClient
{
    NSString *userLoginName;
}

- (void)dealloc
{
    [self.parameters release];
    [super dealloc];
}

- (id)init
{
    self = [super init];
    if(self)
    {
//        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//        userLoginName = [appDelegate getUserLoginName];
        if(!userLoginName)
        {
            userLoginName = @"";
        }
    }
    return self;
}
//封装json提交参数
- (void)asynchronousRequestJson:(NSString *)url method:(NSString *)method parameters:(NSString *)parameterString dic:(NSDictionary *)parameteDic delegate:(id<ASIHTTPRequestDelegate>)delegate onSuccess:(SEL)successHandler onFailure:(SEL)failHandler {
    NSString *encodedValue;
    NSString *sbreq=nil;
    NSError *error=nil;
    
    encodedValue = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSData *data=[NSJSONSerialization dataWithJSONObject:parameteDic options:NSJSONWritingPrettyPrinted error:&error];
    sbreq=[[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    
    NSLog(@"Request URL => %@",encodedValue);
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:encodedValue]];
    [request setRequestMethod:method];
    
    if (parameteDic) {
        for (NSString *key in [parameteDic allKeys]) {
            NSString *value=[parameteDic objectForKey:key];
            [request setPostValue:value forKey:key];
        }
    }    
    [request setDelegate:delegate];
    [request setDidFinishSelector:successHandler];
    [request setDidFailSelector:failHandler];
    [request startAsynchronous];
}


- (void)asynchronousRequest:(NSString *)url method:(NSString *)method parameters:(NSMutableDictionary *)parameters delegate:(id<ASIHTTPRequestDelegate>)delegate  onSuccess:(SEL)successHandler onFailure:(SEL)failHandler userInfo:(NSDictionary *)userInfo{
    NSString *encodedValue;
    encodedValue = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"Request URL => %@",encodedValue);
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
    [request setRequestMethod:method];
    if (parameters) {
        for (NSString *key in [parameters allKeys]) {
            NSString *value=[parameters objectForKey:key];
            [request setPostValue:value forKey:key];
        }
    }
    
    NSMutableDictionary *token = nil;
    if ([Util isLogin]) {
        token = [[Single sharedInstance] getToken];
    }
    
    [request setRequestHeaders:token];
    
    request.tag = (self.pageNumber == 1) ? REQUEST_PAGE_ONE : REQUEST_PAGE_NEXT;
    [request setDelegate:delegate];
    [request setDidFinishSelector:successHandler];
    [request setDidFailSelector:failHandler];
    [request setUserInfo:userInfo];
    [request startAsynchronous];
}


@end
