//
//  ReleaseActivityViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ASIHTTPRequestDelegate.h"

@interface ReleaseActivityViewController : UIViewController <UITableViewDataSource,UITableViewDelegate, UIActionSheetDelegate,ASIHTTPRequestDelegate>
- (IBAction)back:(id)sender;

@property (retain, nonatomic) IBOutlet UITableView *tableViewRelease; //发布活动的tableveiw
@end
