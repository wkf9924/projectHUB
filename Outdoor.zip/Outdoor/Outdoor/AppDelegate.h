//
//  AppDelegate.h
//  Outdoor
//
//  Created by Robin on 14-1-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMPPAutoPing.h"
#import "Reachability.h"
#import "XMPPFramework.h"
#import "XMPPMessageArchiving.h"
#import "XMPPMessageArchivingCoreDataStorage.h"
#import "XMPPRoster.h"
#import "XMPPReconnect.h"
#import "XMPPMessageArchiving.h"
#import "XMPPRosterCoreDataStorage.h"
typedef enum {
    CONNECT_STATUS_NORMAl = 0,
    CONNECT_STATUS_LOGIN = 1,
    CONNECT_STATUS_DISCONNECT = 2
} XmppConnectStatus;

@class MyViewController;





@protocol ChatViewDelegate
-(void)sendMassage:(NSString *)message isSelf:(BOOL)isYou;
- (void)subscription;
@end

@interface AppDelegate : UIResponder <UIApplicationDelegate,XMPPStreamDelegate,XMPPPubSubDelegate> {
}
@property (nonatomic, assign) id <ChatViewDelegate> delegate;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MyViewController *viewController;
@property (nonatomic, retain) UINavigationController *navController;
@property (nonatomic, strong) Reachability *netWorkReachability;

@property (nonatomic,strong,readonly) XMPPStream *xmppStream;
@property (nonatomic,strong,readonly) XMPPReconnect *xmppReconnect;
@property (strong,nonatomic) XMPPPubSub *xmppPubsubManager;

@property (assign) BOOL isXmppConnected;
@property (assign) BOOL allowSelfSignedCertificates;
@property (assign) BOOL allowSSLHostNameMismatch;


@property (nonatomic, strong) XMPPJID *myJID;
@property (nonatomic, strong) NSString *xmppPassword;

-(BOOL)connect;
-(void)disconnect;

- (void)sendMessage:(NSString *)body to:(NSString *)to subject:(NSString *)subject;


/**
 * @brief 在状态栏显示 一些Log
 *
 * @param string 需要显示的内容
 * @param duration  需要显示多长时间
 */
- (void) showStatusWithText:(NSString *) string duration:(NSTimeInterval) duration;

@end
