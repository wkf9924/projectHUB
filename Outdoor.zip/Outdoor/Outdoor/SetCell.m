//
//  SetCell.m
//  Outdoor
//
//  Created by Robin on 14-1-26.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "SetCell.h"

@implementation SetCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_nameLabel release];
    [_moreInfo release];
    [_selectImageView release];
    [_imageViewInfo release];
    [super dealloc];
}
@end
