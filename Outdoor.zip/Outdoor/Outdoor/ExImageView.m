//
//  ExImageView.m
//  uiviewtest
//
//  Created by apple on 13-1-11.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "ExImageView.h"

@implementation ExImageView
@synthesize displayHost;
@synthesize imageDidTouched;
@synthesize imageDidTouch;
@synthesize m_tag;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
    }
    return self;
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(self.displayHost != nil && [self.displayHost respondsToSelector:self.imageDidTouched])
    {
		[self.displayHost performSelectorOnMainThread:self.imageDidTouched withObject:self waitUntilDone:NO];
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(self.displayHost != nil && [self.displayHost respondsToSelector:self.imageDidTouch])
    {
		[self.displayHost performSelectorOnMainThread:self.imageDidTouch withObject:self waitUntilDone:NO];
    }
}
- (void)dealloc
{
    [displayHost release];
    [super dealloc];
}
@end
