//
//  LoginSuccessiewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "LoginSuccessiewController.h"
#import "LoginSeccessCell.h"
#import "Api.h"
#import "MyMessageViewController.h"
#import "ChangePwdViewController.h"
#import "ReleaseActivityViewController.h"
#import "MyInfoViewController.h"
#import "PartakeViewController.h"
@interface LoginSuccessiewController ()
- (IBAction)back:(id)sender;
- (IBAction)ceancelLogin:(id)sender; //取消登录
@end

@implementation LoginSuccessiewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    SWIPE_RIGHT;
    
    UILabel *label = (UILabel *)[self.view viewWithTag:100];
    NSString *uername = [[Util getLoginData] objectForKey:@"userName"];
    label.text = uername;
    
    //开始连接openfire
    
    // Do any additional setup after loading the view from its nib.
}
SWIPE_RIGHT_MONTH;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender {
    NSString *string = [Single sharedInstance].string;
    if ([string isEqualToString:@"wo"]) {
        NAVIGATION_NUM(3)
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *customCell = @"customCell";
	LoginSeccessCell *cell = (LoginSeccessCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
	
	if (cell == nil) {
		//如果没有可重用的单元，我们就从nib里面加载一个，
		NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"LoginSeccessCell"
													 owner:self options:nil];
		//迭代nib重的所有对象来查找NewCell类的一个实例
		for (id oneObject in nib) {
			if ([oneObject isKindOfClass:[LoginSeccessCell class]]) {
				cell = (LoginSeccessCell *)oneObject;
			}
		}
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	}

    NSInteger row = [indexPath row];
    switch (row) {
        case 0:
            cell.titleString.text = @"个人资料";
            cell.cellImageView.image = PNGIMAGE(@"个人资料");
            break;
        case 1:
            cell.titleString.text = @"参与的活动";
            cell.cellImageView.image = PNGIMAGE(@"参加的活动");
            break;
        case 2:
            cell.titleString.text = @"修改密码";
            cell.cellImageView.image = PNGIMAGE(@"修改密码");
            break;
        case 3:
            cell.titleString.text = @"发布的活动";
            cell.cellImageView.image = PNGIMAGE(@"发布的活动");
            break;
            
        default:
            break;
    }
    cell.moreButton.tag = row;
    [cell.moreButton addTarget:self action:@selector(moreButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (void)moreButtonAction:(id)sender {
    UIButton *tagbtn = (UIButton *)sender;
    NSInteger row = tagbtn.tag;
    if (row == 0) {
        MyInfoViewController *myInfoView = [[[MyInfoViewController alloc] init] autorelease];
        
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 1) {
        PartakeViewController  *myInfoView = [[[PartakeViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 2) {
        ChangePwdViewController *myInfoView = [[[ChangePwdViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 3) {
        ReleaseActivityViewController *myInfoView = [[[ReleaseActivityViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = [indexPath row];
    if (row == 0) {
        MyInfoViewController *myInfoView = [[[MyInfoViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 1) {
        PartakeViewController  *myInfoView = [[[PartakeViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 2) {
        ChangePwdViewController *myInfoView = [[[ChangePwdViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
    else if (row == 3) {
        ReleaseActivityViewController *myInfoView = [[[ReleaseActivityViewController alloc] init] autorelease];
        [self.navigationController pushViewController:myInfoView animated:YES];
    }
}

#pragma mark
#pragma mark 登出
- (IBAction)ceancelLogin:(id)sender {
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"是否要注销"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:nil
                                           otherButtonTitles:@"否",@"是", nil]
                          autorelease];
    [alert show];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        return;
    }
    if (buttonIndex == 1) {

        [Single sharedInstance].string = @"";
        [ShareSDK cancelAuthWithType:ShareTypeTencentWeibo];
        [ShareSDK cancelAuthWithType:ShareTypeSinaWeibo];
        
        //登出
        [self logout];
        
        //取消登录
        [Util cancelLogin];
        
        //下线了
        [ApplicationDelegate disconnect];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

//登出
- (void)logout {
    
    NSString *uid = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/",SERVER,USER_LOGOUT];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    [request setRequestMethod:@"POST"];
    [request setPostValue:uid forKey:@"uid"];
    MBPHUD_SHOW;
    [request setCompletionBlock:^{
        MBPHUD_HIDDEN;
        int status =request.responseStatusCode;
        NSLog(@"%d",status);
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
        NSString *string = [root objectForKey:@"responseMessage"];
        NSLog(@"状态：%@ \n root:==%@",string,root);
        
    }];
    [request  setFailedBlock:^{
        MBPHUD_HIDDEN;
    }];
    [request startAsynchronous];
}
@end
