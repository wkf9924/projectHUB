
//
//  ImageCell.m
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ImageCell.h"

@implementation ImageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_imageAA release];
    [_imagePrice release];
    [_price release];
    [_timeLabel release];
    [_titleLab release];
    [_imageViewbg release];
    [_timeImageView release];
    [_buttonData release];
    [_categoryLab release];
    [_residueNumberLab release];
    [super dealloc];
}
@end
