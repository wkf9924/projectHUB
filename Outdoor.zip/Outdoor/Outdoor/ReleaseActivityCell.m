//
//  ReleaseActivityCell.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ReleaseActivityCell.h"

@implementation ReleaseActivityCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_titleString release];
    [_timeLab release];
    [_addLab release];
    [_moreButton release];
    [super dealloc];
}
@end
