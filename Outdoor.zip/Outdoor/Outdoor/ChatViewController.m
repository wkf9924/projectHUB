

#import "ChatViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ChatCustomCell.h"
#import "Api.h"

#define TOOLBARTAG		200
#define TABLEVIEWTAG	300


#define BEGIN_FLAG @"[/"
#define END_FLAG @"]"

@interface ChatViewController ()

- (void)bounceOutAnimationStopped;
- (void)bounceInAnimationStopped;

@end



@implementation ChatViewController
@synthesize titleString = _titleString;
@synthesize chatArray = _chatArray;
@synthesize chatTableView = _chatTableView;
@synthesize messageTextField = _messageTextField;
@synthesize phraseViewController = _phraseViewController;
@synthesize messageString = _messageString;
@synthesize phraseString = _phraseString;
@synthesize lastTime = _lastTime;

@synthesize basetempController;


+ (id)shareChatView{
    static ChatViewController *chatView = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        chatView = [[ChatViewController alloc] init];
    });
    return chatView;
}


- (void)dealloc {
    [_noteNameStirng release];
	[_lastTime release];
	[_phraseString release];
	[_messageString release];
    
	[_phraseViewController release];
	[_messageTextField release];
	[_chatArray release];
	[_titleString release];
	[_chatTableView release];
    
    [super dealloc];
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *image = [UIImage imageNamed:@"返回.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    backBtn.frame = CGRectMake(0, 0,25, 44);
    [backBtn setBackgroundImage:image forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(dismissSelf) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc ] initWithCustomView:backBtn ];
    self.navigationItem.leftBarButtonItem = backItem;
    [backItem release];
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,[UIFont systemFontSize],NSFontAttributeName,nil]];

    self.phraseViewController.chatViewController = self;
    
   	NSMutableArray *tempArray = [[NSMutableArray alloc] init];
	self.chatArray = tempArray;
	[tempArray release];
	
    NSMutableString *tempStr = [[NSMutableString alloc] initWithFormat:@""];
    self.messageString = tempStr;
    [tempStr release];
		
	NSDate   *tempDate = [[NSDate alloc] init];
	self.lastTime = tempDate;
	[tempDate release];
    
    
    //监听键盘高度的变换 
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    // 键盘高度变化通知，ios5.0新增的  
#ifdef __IPHONE_5_0
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (version >= 5.0) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillChangeFrameNotification object:nil];
    }
#endif

}

-(void) dismissSelf{
    MBPHUD_HIDDEN;
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    
}
-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:YES];

	self.title =_titleString;
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    /**
     *创建消息表
     **/
    [self createTableNoteName];
    
	[ApplicationDelegate connect];
	[self.messageTextField setText:self.messageString];
	[self.chatTableView reloadData];
}

- (void)createTableNoteName {
    
    SQLiteOperation *sql_opration = [SQLiteOperation shareDB];
    
    /**
	 * 新建一个消息群组表 toName发送者名称 date消息发送时间 message消息内容 if not exists 如果已存在表则不创建
	 * toName发送者名字 data发送时间 message消息内容 readState消息阅读状态，0为未读，1为已读。
	 * */
    if (![sql_opration isExistsTable:_noteNameStirng]) {
        NSString *creat_table =[NSString stringWithFormat:@"CREATE TABLE %@ (id integer primary key, toName string, message string, data string,readState int, isSelf int)",_noteNameStirng];
        [sql_opration dealData:creat_table paramArray:nil];
    }
    
    NSString * qerry_sql = [NSString stringWithFormat:@"SELECT * FROM %@ ORDER BY id",_noteNameStirng];
    NSArray *qerry_arr = [sql_opration selectData:qerry_sql resultColumns:6];
    NSLog(@"%@",qerry_arr);
    
    
    for (int i = 0; i < [qerry_arr count]; i++) {
        NSString *mess = [NSString stringWithCString:[[[qerry_arr objectAtIndex:i] objectAtIndex:2] cString]encoding:NSUTF8StringEncoding];
        
        //取出存储的来回消息的值。0对方发的。1自己发的消息
        BOOL you = [[[qerry_arr objectAtIndex:i] objectAtIndex:5] boolValue];
        
        //日期
        NSString *dateString = [[qerry_arr objectAtIndex:i] objectAtIndex:3];
        NSString *isyou = [NSString stringWithFormat:@"%d",you];
        
        NSLog(@"Message:%@    isyou:%@   dataStirng:%@",mess, isyou,dateString);
  
        NSMutableArray *array = [NSMutableArray array];
        
        //发送后生成泡泡显示出来 me发的消息  from:YES   收到的消息  from；NO
        UIView *chatView = [self bubbleView:[NSString stringWithFormat:@"%@", mess] from:you];
        NSDate *date = [DateUtil stringToDate:dateString withFormat:@"yy-MM-dd HH:mm"];
        [array addObject:date];
        [array addObject:[NSDictionary dictionaryWithObjectsAndKeys:mess, @"text", @"self", @"speaker", chatView, @"view", nil]];
        [self.chatArray addObjectsFromArray:array];
        
        NSLog(@"chatAreray:%@",self.chatArray);
        [self.chatTableView reloadData];
        [self.chatTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[self.chatArray count]-1 inSection:0] atScrollPosition: UITableViewScrollPositionBottom animated:YES];
        
    }

}

//订阅节点信息
- (void)subscription {
    [ApplicationDelegate.xmppPubsubManager subscribeToNode:_noteNameStirng];
}


//发送消息
-(IBAction)sendMessage_Click:(id)sender
{	
	NSString *messageStr = self.messageTextField.text;
    if (messageStr == nil)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"发送失败！" message:@"发送的内容不能为空！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alert show];
        [alert release];
    }
    else
    {
        NSString *jid = [NSString stringWithFormat:@"all@troop.xinhuwai/%@",_noteNameStirng];
       
        [ApplicationDelegate sendMessage:messageStr to:jid subject:_noteNameStirng];
        [self sendMassage:messageStr isSelf:YES];
    }
    
        self.messageTextField.text = @"";
        [_messageTextField resignFirstResponder];
   
}

//发送消息
-(void)sendMassage:(NSString *)message isSelf:(BOOL)isYou 
{
    
    int isyouNum;
    if (isYou) {
        isyouNum = 1;
    }
    if (!isYou) {
        isyouNum = 0;
    }
    
    
	NSDate *nowTime = [NSDate date];
    
    NSDictionary *message_s = [JSONFunction jsonObjectWithNSString:message];
    //收到的消息
    NSString *message_back = [message_s objectForKey:@"nickMessage"];
    //谁发的
    NSString *nickName = [message_s objectForKey:@"nickName"];
    //节点名字作为表名
    NSString *nodeName = [message_s objectForKey:@"nickJid"];
    
    //isYou  为NO 时说明是back回来的消息
    if (!isYou) {
        message = message_back;
    }
    
	//开始发送
    self.lastTime = nowTime;
    NSMutableArray *array = [NSMutableArray array];
    //发送后生成泡泡显示出来 me发的消息from:YES   收到的消息from；NO
	UIView *chatView = [self bubbleView:[NSString stringWithFormat:@"%@", message] from:isYou];
    [array addObject:nowTime];
    [array addObject:[NSDictionary dictionaryWithObjectsAndKeys:message, @"text", @"self", @"speaker", chatView, @"view", nil]];
    [self.chatArray addObjectsFromArray:array];
    NSLog(@"chatAreray:%@",self.chatArray);
	[self.chatTableView reloadData];
	[self.chatTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[self.chatArray count]-1 inSection:0] atScrollPosition: UITableViewScrollPositionBottom animated:YES];
    
    
    //保存数据库
    NSString *timeString = [DateUtil dateToString:nowTime withFormat:@"yy-MM-dd HH:mm"];
    NSString *isyou = [NSString stringWithFormat:@"%d", isyouNum];
    NSArray *paramarray = [NSArray arrayWithObjects:nickName, message, timeString,isyou, nil];
    NSString *creat_book = STRING_FORMAT_INT(@"INSERT INTO %@ (toName, message, data, isSelf) VALUES (?, ?, ?, ?)", nodeName);
    [[SQLiteOperation shareDB] dealData:creat_book paramArray:paramarray];


}
//选择系统表情
-(IBAction)showPhraseInfo:(id)sender
{   
    self.messageString =[NSMutableString stringWithFormat:@"%@",self.messageTextField.text];
	[self.messageTextField resignFirstResponder];
	if (self.phraseViewController == nil) {
		FaceViewController *temp = [[FaceViewController alloc] initWithNibName:@"FaceViewController" bundle:nil];
		self.phraseViewController = temp;
		[temp release];
	}

    [self presentViewController:self.phraseViewController animated:YES completion:NULL];
}


/*
 生成泡泡UIView
 */
#pragma mark -
#pragma mark Table view methods


- (UIView *)bubbleView:(NSString *)text from:(BOOL)fromSelf {
	// build single chat bubble cell with given text
    UIView *returnView =  [self assembleMessageAtIndex:text from:fromSelf];
    returnView.backgroundColor = [UIColor clearColor];
    UIView *cellView = [[UIView alloc] initWithFrame:CGRectZero];
    cellView.backgroundColor = [UIColor clearColor];
//
	UIImageView *bubbleImageView = [[UIImageView alloc] init];
    UIImageView *headImageView = [[UIImageView alloc] init];
    
    if(fromSelf){
        [headImageView setImage:[UIImage imageNamed:@"face_test.png"]];
        
        UIImage *bubble = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:fromSelf?@"bubbleSelf":@"bubble" ofType:@"png"]];
        [bubbleImageView setImage:[bubble stretchableImageWithLeftCapWidth:21.0f topCapHeight:14.0f]];
        
        returnView.frame= CGRectMake(14.0f , 21.0f, returnView.frame.size.width, returnView.frame.size.height); //文字
        CGRect irec;
        irec.origin.x = 0.0f;
        irec.origin.y = 14.0f;
        irec.size.width = returnView.frame.size.width+38.0f;
        irec.size.width = irec.size.width>45.0f?irec.size.width:45.0f;
        irec.size.height = returnView.frame.size.height+34.0f;
        irec.size.height = irec.size.height>35.0f?irec.size.height:35.0f;
        bubbleImageView.frame = irec;
        cellView.frame = CGRectMake(265.0f-bubbleImageView.frame.size.width, 0.0f,bubbleImageView.frame.size.width+50.0f, bubbleImageView.frame.size.height+30.0f);
        headImageView.frame = CGRectMake(bubbleImageView.frame.size.width, cellView.frame.size.height-50.0f, 50.0f, 50.0f);

    }
	else{
        [headImageView setImage:[UIImage imageNamed:@"face_test.png"]];
        
        UIImage *bubble = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:fromSelf?@"bubbleSelf":@"bubble" ofType:@"png"]];
        [bubbleImageView setImage:[bubble stretchableImageWithLeftCapWidth:21.0f topCapHeight:14.0f]];
        returnView.frame= CGRectMake(70.0f, 21.0f, returnView.frame.size.width, returnView.frame.size.height);
        CGRect irec;
        irec.origin.x = 55.0f;
        irec.origin.y = 14.0f;
        irec.size.width = returnView.frame.size.width+32.0f;
        irec.size.width = irec.size.width>45.0f?irec.size.width:45.0f;
        irec.size.height = returnView.frame.size.height+34.0f;
        irec.size.height = irec.size.height>35.0f?irec.size.height:35.0f;
        bubbleImageView.frame = irec;
        cellView.frame = CGRectMake(0.0f, 0.0f, bubbleImageView.frame.size.width+30.0f,bubbleImageView.frame.size.height+30.0f);
        headImageView.frame = CGRectMake(5.0f, cellView.frame.size.height-50.0f, 50.0f, 50.0f);
    }
    

    [cellView addSubview:bubbleImageView];
    [cellView addSubview:headImageView];
    [cellView addSubview:returnView];
    [bubbleImageView release];
    [returnView release];
    [headImageView release];
    NSLog(@"test:%@",text);

	return [cellView autorelease];
    
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table View DataSource Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.chatArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if ([[self.chatArray objectAtIndex:[indexPath row]] isKindOfClass:[NSDate class]]) {
		return 30;
	}else {
        NSDictionary *viewDic = [self.chatArray objectAtIndex:[indexPath row]];
		UIView *chatView = [viewDic objectForKey:@"view"];
		return chatView.frame.size.height+10;
	}
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    static NSString *CommentCellIdentifier = @"CommentCell";
	ChatCustomCell *cell = (ChatCustomCell*)[tableView dequeueReusableCellWithIdentifier:CommentCellIdentifier];
	if (cell == nil) {
		cell = [[[NSBundle mainBundle] loadNibNamed:@"ChatCustomCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	
	if ([[self.chatArray objectAtIndex:[indexPath row]] isKindOfClass:[NSDate class]]) {
		// Set up the cell...
		NSDateFormatter  *formatter = [[NSDateFormatter alloc] init];
		[formatter setDateFormat:@"yy-MM-dd HH:mm"];
		NSMutableString *timeString = [NSMutableString stringWithFormat:@"%@",[formatter stringFromDate:[self.chatArray objectAtIndex:[indexPath row]]]];
		[formatter release];
				
		[cell.dateLabel setText:timeString];
		

	}else {
		// Set up the cell...
		NSDictionary *chatInfo = [self.chatArray objectAtIndex:[indexPath row]];
		UIView *chatView = [chatInfo objectForKey:@"view"];
		[cell.contentView addSubview:chatView];
	}
    return cell;
}
#pragma mark -
#pragma mark Table View Delegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.messageTextField resignFirstResponder];
}
#pragma mark -
#pragma mark TextField Delegate Methods
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	if(textField == self.messageTextField)
	{
//		[self moveViewUp];
	}
}

-(void) autoMovekeyBoard: (float) h{
    
    
    UIToolbar *toolbar = (UIToolbar *)[self.view viewWithTag:TOOLBARTAG];
    if (iPhone5) {
        toolbar.frame = CGRectMake(0.0f, (float)(568.0-h-44.0), 320.0f, 44.0f);
        
    }
    else {
        toolbar.frame = CGRectMake(0.0f, (float)(480.0-h-44.0), 320.0f, 44.0f);
    }
	
	UITableView *tableView = (UITableView *)[self.view viewWithTag:TABLEVIEWTAG];
    if (iPhone5) {
        tableView.frame = CGRectMake(0.0f, 64.0f, 320.0f,(float)(568.0-h-108.0));
    }
    else {
        tableView.frame = CGRectMake(0.0f, 44.0f, 320.0f,(float)(480.0-h-108.0));
    }
    
}

#pragma mark -
#pragma mark Responding to keyboard events
- (void)keyboardWillShow:(NSNotification *)notification {
    
    /*
     Reduce the size of the text view so that it's not obscured by the keyboard.
     Animate the resize so that it's in sync with the appearance of the keyboard.
     */
    
    NSDictionary *userInfo = [notification userInfo];
    
    // Get the origin of the keyboard when it's displayed.
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    // Get the top of the keyboard as the y coordinate of its origin in self's view's coordinate system. The bottom of the text view's frame should align with the top of the keyboard's final position.
    CGRect keyboardRect = [aValue CGRectValue];
    
    // Get the duration of the animation.
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    
    // Animate the resize of the text view's frame in sync with the keyboard's appearance.
    [self autoMovekeyBoard:keyboardRect.size.height];
}


- (void)keyboardWillHide:(NSNotification *)notification {
    
    NSDictionary* userInfo = [notification userInfo];
    
    /*
     Restore the size of the text view (fill self's view).
     Animate the resize so that it's in sync with the disappearance of the keyboard.
     */
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    

    [self autoMovekeyBoard:0];
}




//图文混排

-(void)getImageRange:(NSString*)message : (NSMutableArray*)array {
    NSRange range=[message rangeOfString: BEGIN_FLAG];
    NSRange range1=[message rangeOfString: END_FLAG];
    //判断当前字符串是否还有表情的标志。
    if (range.length>0 && range1.length>0) {
        if (range.location > 0) {
            [array addObject:[message substringToIndex:range.location]];
            [array addObject:[message substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)]];
            NSString *str=[message substringFromIndex:range1.location+1];
            [self getImageRange:str :array];
        }else {
            NSString *nextstr=[message substringWithRange:NSMakeRange(range.location, range1.location+1-range.location)];
            //排除文字是“”的
            if (![nextstr isEqualToString:@""]) {
                [array addObject:nextstr];
                NSString *str=[message substringFromIndex:range1.location+1];
                [self getImageRange:str :array];
            }else {
                return;
            }
        }
        
    } else if (message != nil) {
            [array addObject:message];
        }
}

#define KFacialSizeWidth  18
#define KFacialSizeHeight 18
#define MAX_WIDTH 150
-(UIView *)assembleMessageAtIndex : (NSString *) message from:(BOOL)fromself
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [self getImageRange:message :array];
    UIView *returnView = [[UIView alloc] initWithFrame:CGRectZero];
    NSArray *data = array;
    UIFont *fon = [UIFont systemFontOfSize:17.0f];
    CGFloat upX = 0;
    CGFloat upY = 0;
    CGFloat X = 0;
    CGFloat Y = 0;
    if (data) {
        for (int i=0;i < [data count];i++) {
            NSString *str=[data objectAtIndex:i];
            NSLog(@"str--->%@",str);
                if ([str hasPrefix: BEGIN_FLAG] && [str hasSuffix: END_FLAG])
            {
                if (upX >= MAX_WIDTH)
                {
                    upY = upY + KFacialSizeHeight;
                    upX = 0;
                    X = 150;
                    Y = upY;
                }
                NSLog(@"str(image)---->%@",str);
                NSString *imageName=[str substringWithRange:NSMakeRange(2, str.length - 3)];
                UIImageView *img=[[UIImageView alloc]initWithImage:[UIImage imageNamed:imageName]];
                img.frame = CGRectMake(upX, upY, KFacialSizeWidth, KFacialSizeHeight);
                [returnView addSubview:img];
                [img release];
                upX=KFacialSizeWidth+upX;
                if (X<150) X = upX;
                    
                
            } else {
                for (int j = 0; j < [str length]; j++) {
                    NSString *temp = [str substringWithRange:NSMakeRange(j, 1)];
                    if (upX >= MAX_WIDTH)
                    {
                        upY = upY + KFacialSizeHeight;
                        upX = 0;
                        X = 150;
                        Y =upY;
                    }
                    CGSize size=[temp sizeWithFont:fon constrainedToSize:CGSizeMake(150, 40)];
                    UILabel *la = [[UILabel alloc] initWithFrame:CGRectMake(upX,upY,size.width,size.height)];
                    la.font = fon;
                    la.text = temp;
                    la.backgroundColor = [UIColor clearColor];
                    [returnView addSubview:la];
                    [la release];
                    upX=upX+size.width;
                    if (X<150) {
                        X = upX;
                    }
                }
            }
        }
    }
    returnView.frame = CGRectMake(15.0f,1.0f, X, Y); //@ 需要将该view的尺寸记下，方便以后使用
    NSLog(@"%.1f %.1f", X, Y);
    return returnView;
}

- (IBAction)back:(id)sender {
 
    [self dismissViewControllerAnimated:YES completion:NULL];
}

@end
