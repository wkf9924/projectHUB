//
//  ChangePwdViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//
#import "ASIHTTPRequestDelegate.h"
@interface ChangePwdViewController : UIViewController <ASIHTTPRequestDelegate>
@property (retain, nonatomic) IBOutlet UITextField *oldTextField;
@property (retain, nonatomic) IBOutlet UITextField *okTextField;
@property (retain, nonatomic) IBOutlet UITextField *newTextField;

- (IBAction)back:(id)sender;
- (IBAction)updateOK:(id)sender;
@end
