//
//  FeedViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "FeedViewController.h"
#import "HUDShare.h"
@interface FeedViewController ()
- (IBAction)hideKeyboard:(id)sender;
- (IBAction)hideKeyboardTextField:(id)sender;

@property (retain, nonatomic) IBOutlet UITextField *nameTextField;
@property (retain, nonatomic) IBOutlet UITextField *phoneTextField;
@end

@implementation FeedViewController

- (void)dealloc {
    [_textViewContent release];
    [_nameTextField release];
    [_phoneTextField release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    [[HUDShare shareInstance] showText:@"womendekl n你试试"];
//    [[HUDShare shareInstance] showComplete:@"我们是你们的未来啊"];
//    [[HUDShare shareInstance] showFail:@"加载失败了"];
//    [[HUDShare shareInstance] showWait:@"请等待啊"];
//    [[HUDShare shareInstance] hideWait];
//    [[HUDShare shareInstance] showWhileExecuted:@"dsafadfasfasdf" sel:@selector(ddd:) target:self withObject:nil];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)submitFeed:(id)sender {
    
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:_textViewContent.text forKey:@"feedback"];
    [common setObject:@"男" forKey:@"sex"];
    [common setObject:@"22" forKey:@"age"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,SUMMIT_FEEDBACK];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"POST" parameters:common delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
    
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [root objectForKey:@"responseMessage"];
    if ([successString isEqualToString:@"success"]) {
        //        [self.view makeToast:@"注册成功"];
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
}




- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    if(textView.tag == 0) {
        textView.text = @"";
        textView.textColor = [UIColor blackColor];
        textView.tag = 1;
    }
    return YES;
}
- (void)textViewDidChange:(UITextView *)textView
{
//    if([textView.text length] == 0)
//    {
//        textView.text = @"Foobar placeholder";
//        textView.textColor = [UIColor lightGrayColor];
//        textView.tag = 0;
//    }
}
- (IBAction)hideKeyboard:(id)sender {
    [_phoneTextField resignFirstResponder];
    [_nameTextField resignFirstResponder];
}

- (IBAction)hideKeyboardTextField:(id)sender {
    [sender resignFirstResponder];
}
@end
