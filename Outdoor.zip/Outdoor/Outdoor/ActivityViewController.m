
//
//  ActivityViewController.m
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ActivityViewController.h"
#import "ImageCell.h"
#import "Api.h"
#import "HCHTTPClient.h"
#import "UIImageView+WebCache.h"
#import "ActivityDetailViewController.h"
#import "MBProgressHUD.h"
#import "DemoTableFooterView.h"
#import "DemoTableHeaderView.h"
#import "SearchViewController.h"
#import "ImageCell.h"
#import "ImageCellTwo.h"
#import "EGOImageView.h"
#import "EGOImageButton.h"

@interface ActivityViewController ()

//单列和双列显示
- (IBAction)showTableViewCellTypeAction:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *butType;

@property (assign) BOOL isTwoCell;
@end

@implementation ActivityViewController
- (void)dealloc {
    [_refreshFooterView release];
    [_refreshHeaderView release];
    [_activityArray release];
    [_tableViewActivity release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [_searchBtn release];
    [_butType release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
            self.activityArray = [NSMutableArray array];
//            self.searchArray = [NSMutableArray array];
        
        
    }
    return self;
}
SWIPE_RIGHT_MONTH;

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    _isTwoCell = YES;
    
    if (!iPhone5) {
        _searchBtn.frame = CGRectMake(_searchBtn.frame.origin.x, _searchBtn.frame.origin.y-5, 48, 42);
    }
    
    SWIPE_RIGHT;
    _tableViewActivity.dataSource = self;
    _tableViewActivity.delegate = self;
    _numberPage = 20;
    _nowPageNum = 1;
    [self activityLoading:1 pageNum:20]; //获取活动
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark *********//加载活动数据
- (void)activityLoading:(int)number pageNum:(int)page {
    
    NSString *numpage = [NSString stringWithFormat:@"%d",number];
    NSString *pgnum = [NSString stringWithFormat:@"%d",page];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@",SERVER,ACTIVITY_GET,numpage,pgnum];
    NSLog(@"urlstring===%@",urlString);
    MBPHUD_SHOW;
    [DataRequest dataWithDic:nil andRequestType:@"GET" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:0 andBlock:^(NSString *requestStr) {
        MBPHUD_HIDDEN;
        NSLog(@"requestStr:%@", requestStr);
        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSLog(@"活动列表：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            [self loadOk];
            return;
        }
        
        NSArray *array = [root objectForKey:@"data"];
        if (!ARRAY_IS_NOT_EMPTY(array)) {
            [self loadOk];
            return;
        }
        
        
        
        NSMutableArray *arrayActivity = [NSMutableArray arrayWithArray:array];
        
        //判断是下拉
        if (number == 1) {
            MBPHUD_HIDDEN;
            //下拉就会清除之前的缓存数据
            [self.activityArray removeAllObjects];
            self.activityArray = arrayActivity;
        }
        else{ //上提
            
            MBPHUD_HIDDEN;
            [self.activityArray addObjectsFromArray:arrayActivity];
        }
        
        [self.tableViewActivity reloadData];
        
        //如果存在
        if (_refreshFooterView != nil || _refreshHeaderView != nil) {
            [_refreshHeaderView removeFromSuperview];
            [_refreshFooterView removeFromSuperview];
        }
        CGRect  _newFrame = CGRectMake(0.0f, self.tableViewActivity.contentSize.height,self.view.frame.size.width,self.tableViewActivity.bounds.size.height);
        NSLog(@"gaodu=%f",self.tableViewActivity.contentSize.height);
        [self createHeaderView];
        [self createFooterView];
        _refreshFooterView.frame = _newFrame;
        [self loadOk];

    }];

//    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
//    httpClient.pageNumber = number;
//    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
//    MBPHUD_SHOW;
}

//- (void)requestFinished:(ASIHTTPRequest *)request {
//    MBPHUD_HIDDEN;
//    NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
//    NSLog(@"root:%@",root);
//    NSString *totalCountString = [[root objectForKey:@"totalCount"] stringValue];
//    if ([totalCountString isEqualToString:@"0"]) {
//        NSLog(@"数据为0");
//        [self loadOk];
//        return;
//    }
//    NSArray *array = [root objectForKey:@"data"];
//    if (!array || array.count == 0  || array == nil) {
//        NSLog(@"活动列表没有数据");
//        [self loadOk];
//        return;
//        
//        
//    }
//
//    NSMutableArray *arrayActivity = [NSMutableArray arrayWithArray:array];
//
//    //判断是下拉还是上提
//    if (request.tag == REQUEST_PAGE_ONE) {
//        MBPHUD_HIDDEN;
//        //下拉就会清除之前的缓存数据
//        [self.activityArray removeAllObjects];
//        self.activityArray = arrayActivity;
//    }
//    else{
//        
//        MBPHUD_HIDDEN;
//        [self.activityArray addObjectsFromArray:arrayActivity];
//    }
//    
//    [self.tableViewActivity reloadData];
//    
//    //如果存在
//    if (_refreshFooterView != nil || _refreshHeaderView != nil) {
//        [_refreshHeaderView removeFromSuperview];
//        [_refreshFooterView removeFromSuperview];
//    }
//    CGRect  _newFrame = CGRectMake(0.0f, self.tableViewActivity.contentSize.height,self.view.frame.size.width,self.tableViewActivity.bounds.size.height);
//    NSLog(@"gaodu=%f",self.tableViewActivity.contentSize.height);
//    [self createHeaderView];
//    [self createFooterView];
//    _refreshFooterView.frame = _newFrame;
//    [self loadOk];
//}
//
//- (void)requestFailed:(ASIHTTPRequest *)request
//{
//    [self loadOk];
//    MBPHUD_HIDDEN;
//    ALERT_DATA;
//}


-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
#pragma mark -tableDelegete
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_isTwoCell) {
        return self.activityArray.count;
    } else {
        return [self.activityArray count]/2 + [self.activityArray count]%2;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (_isTwoCell == YES) {
        static NSString *identifier = @"ImageCell";
        ImageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"ImageCell" owner:self options:nil];
            cell = [array objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellEditingStyleNone;
        //活动标题
        cell.titleLab.text = [[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"title"];
        
        //活动封面图
        NSString *urlString = [[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"image"];
        cell.imageViewbg.placeholderImage = PNGIMAGE(@"默认图片活动");
        [cell.imageViewbg performSelectorOnMainThread:@selector(setImageURL:) withObject:[NSURL URLWithString:urlString] waitUntilDone:NO];
        //人均消费
        NSDictionary *dic = [self.activityArray objectAtIndex:indexPath.row];
        if ([dic objectForKey:@"cost"]) {
            NSString *priceStr = [[[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"cost"] stringValue];
            NSString *stringPrice = [NSString stringWithFormat:@"%@.00元",priceStr];
            cell.price.text = stringPrice;
        }
        
        else {
            cell.price.text = @"0.00元";
        }
        //类别
        cell.categoryLab.text = [[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"category"];
        
        //已报名人数
        NSString *residueNumberString = [[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"residueNumber"];
        //剩余人数
        NSString *applyNumberString = [[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"applyNumber"];
        cell.residueNumberLab.text = [NSString stringWithFormat:@"已报名:%@/剩余:%@", residueNumberString, applyNumberString];
        
        //标题
        cell.titleLab.text =[[self.activityArray objectAtIndex:indexPath.row] objectForKey:@"title"];
        
        //日期
        NSDate *refund = [DateUtil stringToDate:[[_activityArray objectAtIndex:indexPath.row] objectForKey:@"expiration"] withFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *refundString = [DateUtil dateToString:refund withFormat:@"YYYY-MM-dd"];
        cell.timeLabel.text = refundString;
        
        cell.buttonData.tag = indexPath.row;
        [cell.buttonData addTarget:self action:@selector(deatilApply:) forControlEvents:UIControlEventTouchUpInside];
        return cell;
        

    }
    else {
        //一行两列数据排列方式
        NSMutableDictionary *object =nil;
        if((indexPath.row*2) <[self.activityArray count]){
            object = [self.activityArray objectAtIndex:indexPath.row*2];
        }
        
        NSMutableDictionary *object2 =nil;
        if ((indexPath.row*2+1) <[self.activityArray count]) {
            object2 = [self.activityArray objectAtIndex:indexPath.row*2+1];
        }
        

        
        static NSString *identifier = @"ImageCellTwo";
        ImageCellTwo *cellTwo = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cellTwo == nil) {
            NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"ImageCellTwo" owner:self options:nil];
            cellTwo = [array objectAtIndex:0];
        }
        cellTwo.selectionStyle = UITableViewCellEditingStyleNone;

        
        if (object2 == nil) {
            cellTwo.imageViewRight.hidden = YES;
            cellTwo.titleRight.hidden = YES;
            cellTwo.timeRight.hidden = YES;
            cellTwo.priceRight.hidden = YES;
            cellTwo.frameImageView.hidden = YES;
            cellTwo.defaultImage.hidden = YES;
            cellTwo.timeImage.hidden = YES;
            cellTwo.timeItemImage.hidden = YES;
            cellTwo.priceRight.hidden = YES;
            cellTwo.btn_right.hidden = YES;
            cellTwo.priceImage.hidden = YES;
            cellTwo.labBotton.hidden = YES;
            cellTwo.rightView.hidden = YES;
        } else {
            cellTwo.imageViewRight.hidden = NO;
            cellTwo.titleRight.hidden = NO;
            cellTwo.timeRight.hidden = NO;
            cellTwo.priceRight.hidden = NO;
            cellTwo.frameImageView.hidden = NO;
            cellTwo.defaultImage.hidden = NO;
            cellTwo.timeImage.hidden = NO;
            cellTwo.timeItemImage.hidden = NO;
            cellTwo.priceRight.hidden = NO;
            cellTwo.btn_right.hidden = NO;
            cellTwo.priceImage.hidden = NO;
            cellTwo.labBotton.hidden = NO;
            cellTwo.rightView.hidden = NO;
           
        }
        
        
        //已报名人数左
        NSString *residueNumberStringLeft = [object objectForKey:@"residueNumber"];
        //剩余人数
        NSString *applyNumberStringLeft = [object objectForKey:@"applyNumber"];
        cellTwo.applyLabel.text = [NSString stringWithFormat:@"已报名:%@/剩余:%@", residueNumberStringLeft, applyNumberStringLeft];
        //右已报名
        NSString *residueNumberString = [object2 objectForKey:@"residueNumber"];
        NSString *applyNumberString = [object2 objectForKey:@"applyNumber"];
        cellTwo.applyRightLabel.text = [NSString stringWithFormat:@"已报名:%@/剩余:%@", residueNumberString, applyNumberString];
        
        //左边的类别
        cellTwo.categoryLeft.text = [object objectForKey:@"category"];
        //右边的类别
        cellTwo.categoryRight.text = [object2 objectForKey:@"category"];
        //活动标题
        cellTwo.titleLeft.text = [object objectForKey:@"title"];
        cellTwo.titleRight.text = [object2 objectForKey:@"title"];
        
        //活动封面图
        NSString *urlStringLeft = [object objectForKey:@"image"];
        NSString *urlStringRight = [object2 objectForKey:@"image"];
        cellTwo.imageViewLeft.placeholderImage = PNGIMAGE(@"默认图片活动");
        cellTwo.imageViewRight.placeholderImage = PNGIMAGE(@"默认图片活动");
        [cellTwo.imageViewLeft performSelectorOnMainThread:@selector(setImageURL:) withObject:[NSURL URLWithString:urlStringLeft] waitUntilDone:NO];
        [cellTwo.imageViewRight performSelectorOnMainThread:@selector(setImageURL:) withObject:[NSURL URLWithString:urlStringRight] waitUntilDone:NO];
        
        //人均消费
        //        NSDictionary *dic = [self.activityArray objectAtIndex:indexPath.row];
        if ([object objectForKey:@"cost"]) {
            NSString *priceStrLeft = [[object objectForKey:@"cost"] stringValue];
            NSString *priceStrRitht = [[object2 objectForKey:@"cost"] stringValue];
            NSString *stringPriceLeft = [NSString stringWithFormat:@"%@.00元",priceStrLeft];
            NSString *stringPriceRight = [NSString stringWithFormat:@"%@.00元",priceStrRitht];
            cellTwo.prictLeft.text = stringPriceLeft;
            cellTwo.priceRight.text = stringPriceRight;
        }
        
        else {
            cellTwo.prictLeft.text = @"0.00元";
            cellTwo.priceRight.text = @"0.00元";
        }
        
       
        //左边日期
        NSDate *refundLeft = [DateUtil stringToDate:[object objectForKey:@"expiration"] withFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *refundStringLeft = [DateUtil dateToString:refundLeft withFormat:@"YYYY-MM-dd"];
        cellTwo.timeLeft.text = refundStringLeft;
        
        if (object2 != nil) {
            //右边日期
            NSDate *refundRight = [DateUtil stringToDate:[object2 objectForKey:@"expiration"] withFormat:@"yyyy-MM-dd HH:mm:ss"];
            NSString *refundStringRight = [DateUtil dateToString:refundRight withFormat:@"YYYY-MM-dd"];
            cellTwo.timeRight.text = refundStringRight;
        }
  
        NSInteger activityTid1 = [[object objectForKey:@"tid"]  intValue];
        NSInteger activityTid2 = [[object2 objectForKey:@"tid"] intValue];
        
        cellTwo.btn_left.tag = activityTid1;
        cellTwo.btn_right.tag = activityTid2;
        
        [cellTwo.btn_left addTarget:self action:@selector(deatilApply:) forControlEvents:UIControlEventTouchUpInside];
        [cellTwo.btn_right addTarget:self action:@selector(deatilApply:) forControlEvents:UIControlEventTouchUpInside];
        
        return cellTwo;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_isTwoCell == YES) {
        return 280;
    } else {
        return 200;
    }
   
}

- (IBAction)back:(id)sender {
    MBPHUD_HIDDEN;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)deatilApply:(UIDataButton *)sender {
    
    NSInteger tid = [sender tag];
    ActivityDetailViewController *ad = [[[ActivityDetailViewController alloc] init] autorelease];
    if (_isTwoCell) {
        ad.tidString = [[self.activityArray objectAtIndex:sender.tag] objectForKey:@"tid"];
    }
    else {
        ad.tidString = STRING_FORMAT_INT(@"%d", tid);
    }
    
    [self.navigationController pushViewController:ad animated:YES];
}



#pragma mark - EGORefreshTableHeader
-(void)createHeaderView{
    if (_refreshHeaderView && [_refreshFooterView superview]) {
        [_refreshHeaderView removeFromSuperview];
    }
	_refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame: CGRectMake(0.0f, 0.0f - self.view.bounds.size.height,self.view.frame.size.width, self.view.bounds.size.height)];
    _refreshHeaderView.backgroundColor = [UIColor clearColor];
    _refreshHeaderView.delegate = self;
	[self.tableViewActivity  addSubview:_refreshHeaderView];
    [_refreshHeaderView refreshLastUpdatedDate];
    
}

#pragma mark - EGORefreshTableFooter
-(void)createFooterView{
    if (_refreshFooterView && [_refreshFooterView superview]) {
        [_refreshFooterView removeFromSuperview];
    }
    
	if (self.tableViewActivity.contentSize.height>=self.view.bounds.size.height){
        _refreshFooterView = [[EGORefreshTableFooterView alloc] initWithFrame:CGRectMake(0.0f, self.tableViewActivity.frame.size.height, self.tableViewActivity.frame.size.width, self.tableViewActivity.bounds.size.height)];
        _refreshFooterView.backgroundColor  = [UIColor clearColor];
        _refreshFooterView.delegate = self;
        
        [self.tableViewActivity addSubview:_refreshFooterView];
        
        [_refreshFooterView refreshLastUpdatedDate];
        
        CGRect  _newFrame =  CGRectMake(0.0f, self.tableViewActivity.frame.size.height,self.view.frame.size.width, self.tableViewActivity.bounds.size.height);
        _refreshFooterView.frame = _newFrame;
    }
}
#pragma mark - EGORefreshTableDelegate
- (void)egoRefreshTableHeaderDidTriggerRefresh:(UIView*)view
{
    //顶部数据刷新
    if ([view isEqual:_refreshHeaderView]) {
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
        [self activityLoading:1 pageNum:20];
        _nowPageNum =1;
//        _numberPage = 10;
    }
    //底部数据刷新
    else if([view isEqual:_refreshFooterView]) {
        _reloading = NO;
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
        
        _nowPageNum++;
//        _numberPage = _numberPage + 10;
        [self activityLoading:_nowPageNum pageNum:20];
    }
}
-(void)loadOk
{
    _reloading = NO;
    [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
    [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
    
}
- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(UIView*)view
{
    return _reloading;
}



#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
    
    //  should be calling your tableviews data source model to reload
    //  put here just for demo
    _reloading = YES;
    
}

- (void)doneLoadingTableViewData{
    
    //  model should call this when its done loading
    _reloading = NO;
    [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableViewActivity];
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    [_refreshFooterView egoRefreshScrollViewDidScroll:scrollView];
    
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	[_refreshFooterView egoRefreshScrollViewDidEndDragging:scrollView];
}
- (IBAction)searchAction:(id)sender {
    SearchViewController *search = [[[SearchViewController alloc] init] autorelease];
    search.delegeta = self;
    [self.navigationController pushViewController:search animated:YES];
}

- (void)setSearchData:(NSDictionary *)dic; {
    NSLog(@"查询返回%@",dic);
    NSString *successString = [[dic objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        NSLog(@"返回%@",dic);
        return;
        
    }
    NSMutableArray *array = [dic objectForKey:@"data"];
    self.activityArray = array;
    [_tableViewActivity reloadData];
    
}
- (IBAction)showTableViewCellTypeAction:(id)sender {
    
    if (_isTwoCell == YES) {
        _isTwoCell = NO;
        [_butType setBackgroundImage:PNGIMAGE(@"双列模式") forState:0];
        [_tableViewActivity reloadData];
    }
    else {
        _isTwoCell = YES;
        [_butType setBackgroundImage:PNGIMAGE(@"单列显示") forState:0];
        [_tableViewActivity reloadData];
    }
//    [self loadOk];
//
//    CGRect  _newFrame = CGRectMake(0.0f, self.tableViewActivity.contentSize.height,self.view.frame.size.width,self.tableViewActivity.bounds.size.height);
//    [self createHeaderView];
//    [self createFooterView];
//    _refreshFooterView.frame = _newFrame;
//    [self loadOk];
}
@end
