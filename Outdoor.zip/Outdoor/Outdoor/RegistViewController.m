//
//  RegistViewController.m
//  Outdoor
//
//  Created by Robin on 14-2-14.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "RegistViewController.h"

@interface RegistViewController ()

@end

@implementation RegistViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    SWIPE_RIGHT;
    // Do any additional setup after loading the view from its nib.
}
SWIPE_RIGHT_MONTH;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_username release];
    [_password release];
    [_email release];
    [super dealloc];
}
- (IBAction)registerAction:(id)sender {
    
    if ([_username.text isEqualToString:@""]) {
        [self.view makeToast:@"用户名不能为空"];
        return;
    
    }
    if ([_password.text isEqualToString:@""]) {
        [self.view makeToast:@"密码不能为空"];
        return;
    }
    if ([_email.text isEqualToString:@""]) {
        [self.view makeToast:@"邮箱不能为空"];
        return;
    }
    
    NSString *userName = [_username.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:userName forKey:@"username"];
    [common setObject:_password.text forKey:@"password"];
    [common setObject:_email.text forKey:@"email"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,REGISTER_USER];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"POST" parameters:common delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [[root objectForKey:@"success"] stringValue];
     NSString *responseMessage = [root objectForKey:@"responseMessage"];
    NSLog(@"responseMessage====%@",responseMessage);
    if (![successString isEqualToString:@"1"]) {
        [[iToast makeToast:@"注册失败"] show];
        return;
    } else {
        [[iToast makeToast:@"注册成功,请登录"] show];
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
}
@end
