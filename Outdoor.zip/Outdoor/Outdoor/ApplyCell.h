//
//  ApplyCell.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplyCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *titleString;
@property (retain, nonatomic) IBOutlet UILabel *timeLab;
@property (retain, nonatomic) IBOutlet UILabel *addLab;
- (IBAction)moreAction:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *moreBtn;

@end
