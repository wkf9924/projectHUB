//
//  ActivityDetailViewController.m
//  Outdoor
//
//  Created by Robin on 14-2-8.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ActivityDetailViewController.h"
#import "Api.h"
#import "CollectViewController.h"
#import "Util.h"
#import "SignUpVC.h"
#import <ShareSDK/ShareSDK.h>

#define ScrollView_ImageView_Weight 306
#define ScrollView_ImageView_Height 190



@interface ActivityDetailViewController ()
@property (retain,nonatomic) NSMutableDictionary *rootDic;
@property (retain, nonatomic) IBOutlet UILabel *money;//定金
@property (retain, nonatomic) IBOutlet UIButton *applyBut;
@property (retain, nonatomic) IBOutlet UIButton *collectBtn;




- (IBAction)applyAction:(id)sender;//我要报名
- (IBAction)collect:(id)sender; //收藏
- (IBAction)telAction:(id)sender; //打电话
- (IBAction)shareAction:(id)sender; //分享
- (IBAction)groupChatAction:(id)sender; //群聊
@end

@implementation ActivityDetailViewController

- (void)dealloc {
    [_rootDic release];
    [_navImageView release];
    [_mainScrollView release];
    [_mainView release];
    [_scImage release];
    [_lbInfo release];
    [_pageCotrol release];
    [_lbTime release];
    [_lbprice release];
    [_peopleNum release];
    [_lbcaptain release];
    [_contentLabel release];
    [_uid release];
    [_tidString release];
    [_money release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [_applyBut release];
    [_collectBtn release];
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.rootDic = [NSMutableDictionary dictionary];
       
    }
    return self;
}

#define ALPHA_BUT 0.8f
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //收藏界面过来的
    if (_isShowCollect == YES) {
        _collectBtn.enabled = NO;
        _collectBtn.alpha = ALPHA_BUT;
        _applyBut.enabled = YES;
    }
    //
    if (_isShowApply == YES) {
        _collectBtn.enabled = NO;
        _applyBut.enabled = YES;
        _applyBut.alpha = ALPHA_BUT;
    }
    
    if (_isShowApply == YES && _isShowCollect == YES) {
        _collectBtn.enabled = NO;
        _applyBut.enabled = NO;
        _applyBut.alpha = ALPHA_BUT;
        _collectBtn.alpha = ALPHA_BUT;
    }
    
    //参加活动和发布活动过来的
    SWIPE_RIGHT;
    
    NSString *uidStr = @"";
    if ([Util isLogin]) {
        uidStr = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
    }
    else {
        uidStr = @"0";
    }
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@",SERVER,ACTIVITY_DETAIL,self.tidString,uidStr];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
    
    
}
- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        ALERT_DATA

        return;
    }
    NSDictionary *dataDic = [root objectForKey:@"data"];
    if (dataDic == nil && [dataDic isKindOfClass:[NSDictionary class]]) {
        ALERT_DATA
        return;
    }
    
    //内容 计算内容的高度
    self.contentLabel.text = [[root objectForKey:@"data"] objectForKey:@"textContent"];
    [self.contentLabel setNumberOfLines:0];
    NSString *string1 = self.contentLabel.text;
    self.contentLabel.font = [UIFont systemFontOfSize:15];
    CGSize labsize1 = [string1 sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(self.contentLabel.frame.size.width, 9999) lineBreakMode:NSLineBreakByWordWrapping];
    self.contentLabel.frame = CGRectMake(self.contentLabel.frame.origin.x, self.contentLabel.frame.origin.y, self.contentLabel.frame.size.width, labsize1.height);
    self.contentLabel.text= string1;
    self.contentLabel.backgroundColor = [UIColor clearColor];
    self.contentLabel.font = [UIFont systemFontOfSize:15];
    self.mainScrollView.contentSize = CGSizeMake(self.mainView.frame.size.width, self.mainView.frame.size.height + self.contentLabel.frame.size.height);
    
    //标题
    self.lbInfo.text =[[root objectForKey:@"data"] objectForKey:@"title"];
    //图片
    NSString *imageString = [[root objectForKey:@"data"] objectForKey:@"image"];
    NSMutableArray *arrayImage = [NSMutableArray arrayWithObjects:imageString, nil];
    [self showProductImageOnSrollView:arrayImage];
    
    //价格
    if ([[[root objectForKey:@"data"] objectForKey:@"cost"] stringValue]) {
       self.lbprice.text = [NSString stringWithFormat:@"%@.00元",[[[root objectForKey:@"data"] objectForKey:@"cost"] stringValue]];
    }
    
    //已报名
    self.peopleNum.text =[NSString stringWithFormat:@"已报名:%@人",[[[root objectForKey:@"data"] objectForKey:@"applynumber"] stringValue]];
    //领队
    self.lbcaptain.text = [NSString stringWithFormat:@"领队人:%@", [[root objectForKey:@"data"] objectForKey:@"sponsor"]];

    //日期
    NSDate *refund = [DateUtil stringToDate:[[root objectForKey:@"data"] objectForKey:@"starttimefrom"] withFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *refundStringFrom = [DateUtil dateToString:refund withFormat:@"MM-dd"];
    
    NSDate *refund1 = [DateUtil stringToDate:[[root objectForKey:@"data"] objectForKey:@"starttimeto"] withFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *refundStringTo = [DateUtil dateToString:refund1 withFormat:@"MM-dd"];
    self.lbTime.text = [NSString stringWithFormat:@"%@-%@",refundStringFrom,refundStringTo];
    self.rootDic = [root objectForKey:@"data"];
    
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
    ALERT_DATA
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark *********我要报名

- (IBAction)applyAction:(id)sender {
    if ([Util isLogin]) {
        
        SignUpVC *singn = [[[SignUpVC alloc] init] autorelease];
        NSString *stringUfield = [_rootDic objectForKey:@"ufield"];
        singn.stringUf = stringUfield;
        singn.signDic = _rootDic;
        [self.navigationController pushViewController:singn animated:YES];

    } else {
        [Single sharedInstance].string = @"xiangQing";
        LOGIN_VIEWCONTROLLER;
    }
}

- (void)requestAppleyFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [root objectForKey:@"responseMessage"];
    if ([successString isEqualToString:@"success"]) {
        [self.view makeToast:@"报名成功"];
    }
}

- (void)requestAppleyFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
}


#pragma mark
#pragma mark 收藏
- (IBAction)collect:(id)sender {
    
    if ([Util isLogin]) {
        NSString *uidStirng = STRING_FORMAT_INT(@"%@", [[Util getLoginData] objectForKey:@"uid"]);
        NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
        [common setObject:uidStirng forKey:@"uid"];
        [common setObject:_tidString forKey:@"tid"];
        NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ADD_FAVORITE];
        
        [DataRequest dataWithDic:common andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
            NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
            NSLog(@"收藏返回：%@", root);
            
            NSString *successString = [[root objectForKey:@"success"] stringValue];
            NSLog(@"responseString:%@",successString);
            if ([successString isEqualToString:@"1"]) {
                [self.view makeToast:@"收藏成功"];
            } else {
                [self.view makeToast:@"收藏失败"];
            }
            
        }];

        
//        HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
//        [httpClient asynchronousRequest:urlString method:@"POST" parameters:common delegate:self onSuccess:@selector(requestFavoriteFinished:) onFailure:@selector(requestFavoriteFailed:) userInfo:nil];
//        MBPHUD_SHOW;
        return;
    }
    [Single sharedInstance].string = @"shoucang";
    LOGIN_VIEWCONTROLLER;
    
}

- (void)requestFavoriteFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    NSLog(@"responseString:%@",successString);
    if ([successString isEqualToString:@"1"]) {
        [self.view makeToast:@"收藏成功"];
    } else {
        [self.view makeToast:@"收藏失败"];
    }
}

- (void)requestFavoriteFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
    ALERT_DATA
}

- (IBAction)telAction:(id)sender {
    
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"是否拨打电话"
                                                     message:nil
                                                    delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消",@"确定", nil]
                          autorelease];
    [alert show];
}

#pragma mark
#pragma mark   ******分享**********
- (IBAction)shareAction:(id)sender
{
    NSString *imagePath = [[NSBundle mainBundle] pathForResource:IMAGE_NAME ofType:IMAGE_EXT];
    
    ///#begin zh-cn
    //构造分享内容
    ///#end
    ///#begin en
    //Create a share content.
    ///#end
    id<ISSContent> publishContent = [ShareSDK content:CONTENT
                                       defaultContent:@""
                                                image:[ShareSDK imageWithPath:imagePath]
                                                title:@"ShareSDK"
                                                  url:@"http://www.sharesdk.cn"
                                          description:NSLocalizedString(@"TEXT_TEST_MSG", @"这是一条测试信息")
                                            mediaType:SSPublishContentMediaTypeNews];
    
    ///#begin zh-cn
    ///////////////////////
    //以下信息为特定平台需要定义分享内容，如果不需要可省略下面的添加方法
    
    ///#begin zh-cn
    //定制微信好友信息
    ///#end
    ///#begin en
    //Customized WeChat Session information
    ///#end
    [publishContent addWeixinSessionUnitWithType:INHERIT_VALUE
                                         content:INHERIT_VALUE
                                           title:NSLocalizedString(@"TEXT_HELLO_WECHAT_SESSION", @"Hello 微信好友!")
                                             url:INHERIT_VALUE
                                      thumbImage:[ShareSDK imageWithUrl:@"http://img1.bdstatic.com/img/image/67037d3d539b6003af38f5c4c4f372ac65c1038b63f.jpg"]
                                           image:INHERIT_VALUE
                                    musicFileUrl:nil
                                         extInfo:nil
                                        fileData:nil
                                    emoticonData:nil];
    
    ///#begin zh-cn
    //定制微信朋友圈信息
    ///#end
    ///#begin en
    //Customized WeChat Timeline information
    ///#end
    [publishContent addWeixinTimelineUnitWithType:[NSNumber numberWithInteger:SSPublishContentMediaTypeNews]
                                          content:INHERIT_VALUE
                                            title:NSLocalizedString(@"TEXT_HELLO_WECHAT_TIMELINE", @"Hello 微信朋友圈!")
                                              url:@"http://y.qq.com/i/song.html#p=7B22736F6E675F4E616D65223A22E4BDA0E4B88DE698AFE79C9FE6ADA3E79A84E5BFABE4B990222C22736F6E675F5761704C69766555524C223A22687474703A2F2F74736D7573696332342E74632E71712E636F6D2F586B303051563558484A645574315070536F4B7458796931667443755A68646C2F316F5A4465637734356375386355672B474B304964794E6A3770633447524A574C48795333383D2F3634363232332E6D34613F7569643D32333230303738313038266469723D423226663D312663743D3026636869643D222C22736F6E675F5769666955524C223A22687474703A2F2F73747265616D31382E71716D757369632E71712E636F6D2F33303634363232332E6D7033222C226E657454797065223A2277696669222C22736F6E675F416C62756D223A22E5889BE980A0EFBC9AE5B08FE5B7A8E89B8B444E414C495645EFBC81E6BC94E594B1E4BC9AE5889BE7BAAAE5BD95E99FB3222C22736F6E675F4944223A3634363232332C22736F6E675F54797065223A312C22736F6E675F53696E676572223A22E4BA94E69C88E5A4A9222C22736F6E675F576170446F776E4C6F616455524C223A22687474703A2F2F74736D757369633132382E74632E71712E636F6D2F586C464E4D31354C5569396961495674593739786D436534456B5275696879366A702F674B65356E4D6E684178494C73484D6C6A307849634A454B394568572F4E3978464B316368316F37636848323568413D3D2F33303634363232332E6D70333F7569643D32333230303738313038266469723D423226663D302663743D3026636869643D2673747265616D5F706F733D38227D"
                                       thumbImage:[ShareSDK imageWithUrl:@"http://img1.bdstatic.com/img/image/67037d3d539b6003af38f5c4c4f372ac65c1038b63f.jpg"]
                                            image:INHERIT_VALUE
                                     musicFileUrl:@"http://mp3.mwap8.com/destdir/Music/2009/20090601/ZuiXuanMinZuFeng20090601119.mp3"
                                          extInfo:nil
                                         fileData:nil
                                     emoticonData:nil];

    ///#begin zh-cn
    //结束定制信息
    ////////////////////////
    
    
    //创建弹出菜单容器
    ///#end
    ///#begin en
    //End customized information
    ////////////////////////
    
    
    //Create a pop-up menu container
    ///#end
    id<ISSContainer> container = [ShareSDK container];
    [container setIPadContainerWithView:sender arrowDirect:UIPopoverArrowDirectionUp];
    
    id<ISSAuthOptions> authOptions = [ShareSDK authOptionsWithAutoAuth:YES
                                                         allowCallback:NO
                                                         authViewStyle:SSAuthViewStyleFullScreenPopup
                                                          viewDelegate:nil
                                               authManagerViewDelegate:self];
    
    ///#begin zh-cn
    //在授权页面中添加关注官方微博
    ///#end
    ///#begin en
    //Adding official Weibo concern in the authorization page
    ///#end
    [authOptions setFollowAccounts:[NSDictionary dictionaryWithObjectsAndKeys:
                                    [ShareSDK userFieldWithType:SSUserFieldTypeName value:@"ShareSDK"],
                                    SHARE_TYPE_NUMBER(ShareTypeSinaWeibo),
                                    [ShareSDK userFieldWithType:SSUserFieldTypeName value:@"ShareSDK"],
                                    SHARE_TYPE_NUMBER(ShareTypeTencentWeibo),
                                    nil]];
    
    id<ISSShareOptions> shareOptions = [ShareSDK simpleShareOptionsWithTitle:NSLocalizedString(@"TEXT_SHARE_TITLE", @"内容分享")
                                                           shareViewDelegate:self];
    
    ///#begin zh-cn
    //弹出分享菜单
    ///#end
    ///#begin en
    //Pop-up share menu
    ///#end
    [ShareSDK showShareActionSheet:container
                         shareList:nil
                           content:publishContent
                     statusBarTips:YES
                       authOptions:authOptions
                      shareOptions:shareOptions
                            result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
                                
                                if (state == SSPublishContentStateSuccess)
                                {
                                    NSLog(NSLocalizedString(@"TEXT_SHARE_SUC", @"分享成功"));
                                }
                                else if (state == SSPublishContentStateFail)
                                {
                                    NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"分享失败,错误码:%d,错误描述:%@"), [error errorCode], [error errorDescription]);
                                }
                            }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://10086"]];
    }
}

#pragma mark
#pragma mark 手势往右滑动

SWIPE_RIGHT_MONTH;

- (void) showProductImageOnSrollView:(NSMutableArray*)imageArray{
    
    if (!imageArray || ![imageArray isKindOfClass:[NSMutableArray class]]) {
        return;
    }
    
    //wkf修改
    [_scImage setContentSize:CGSizeMake(ScrollView_ImageView_Weight*imageArray.count , ScrollView_ImageView_Height)];//设置ScrollView滚动范围
    _scImage.clipsToBounds = NO;
    _scImage.delegate = self;
    _pageCotrol.currentPage = 0;
    for (int i = 0; i < imageArray.count; i++) {
        //创建图片
        UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(ScrollView_ImageView_Weight*i, 0,ScrollView_ImageView_Weight, ScrollView_ImageView_Height)];

        [imageview setImageWithURL:[NSURL URLWithString:[imageArray objectAtIndex:i]] placeholderImage:PNGIMAGE(@"默认图片活动")];
        imageview.userInteractionEnabled = YES;
        [_scImage addSubview:imageview];
        [imageview release];
    }
    //设置PageControl页数
    [_pageCotrol setNumberOfPages:imageArray.count];
    [_pageCotrol setPageIndicatorTintColor:[UIColor whiteColor]];
    [_pageCotrol setCurrentPageIndicatorTintColor:[UIColor blueColor]];
    [_pageCotrol bringSubviewToFront:_scImage];
    
}

- (void) scrollViewDidScroll:(UIScrollView *)scrollView
{
    self.pageCotrol.currentPage = scrollView.contentOffset.x/251;
}

- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark *********UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        SignUpVC *singn = [[[SignUpVC alloc] init] autorelease];
        NSString *stringUfield = [_rootDic objectForKey:@"ufield"];
        singn.stringUf = stringUfield;
        singn.signDic = _rootDic;

        [self.navigationController pushViewController:singn animated:YES];
    }else if (buttonIndex == 1) {
        [self telAction:nil];
    }else if(buttonIndex == 2) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"sms:10086"]];
    }else if(buttonIndex == 3) {
       
    }
    
}
- (IBAction)groupChatAction:(id)sender {
}
@end
