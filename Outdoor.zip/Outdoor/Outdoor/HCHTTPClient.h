//
//  HCHTTPClient.h
//  HC
//
//  Created by Sylar on 13-10-18.
//  Copyright (c) 2013年 Sylar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIFormDataRequest.h"
#import "ASIHTTPRequestDelegate.h"
#import "AppDelegate.h"


@interface HCHTTPClient : NSObject

- (void)asynchronousRequestJson:(NSString *)url method:(NSString *)method parameters:(NSString *)parameterString dic:(NSDictionary *)parameteDic delegate:(id<ASIHTTPRequestDelegate>)delegate onSuccess:(SEL)successHandler onFailure:(SEL)failHandler;

- (void)asynchronousRequest:(NSString *)url method:(NSString *)method parameters:(NSMutableDictionary *)parameters delegate:(id<ASIHTTPRequestDelegate>)delegate  onSuccess:(SEL)successHandler onFailure:(SEL)failHandler userInfo:(NSDictionary *)userInfo;

@property (nonatomic,retain) NSMutableDictionary *parameters;
@property (assign) int pageNumber;
@end
