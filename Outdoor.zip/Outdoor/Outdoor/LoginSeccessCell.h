//
//  LoginSeccessCell.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginSeccessCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titleString;
@property (retain, nonatomic) IBOutlet UIImageView *cellImageView;
@property (retain, nonatomic) IBOutlet UIButton *moreButton;

@end
