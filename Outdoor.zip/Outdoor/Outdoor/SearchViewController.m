//
//  SearchViewController.m
//  Outdoor
//
//  Created by Robin on 14-2-12.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "SearchViewController.h"
#import "Api.h"
@interface SearchViewController ()

@property (retain, nonatomic) IBOutlet UITextField *keyWordTextField;
@property (retain, nonatomic) NSMutableArray *arrayCategory; //类目
@property (retain, nonatomic) NSMutableArray *conditionArray; //条件array
@property (retain, nonatomic) NSMutableArray *hotArray; //热门条件array
@property (assign) BOOL isHotBool; //点击的是类型中的按钮还是热门中得。 YES为热门

- (IBAction)searchAction:(id)sender;
- (IBAction)textFiledReturnEditing:(id)sender;
@end

@implementation SearchViewController

- (void)dealloc {
    [_hotArray release];
    [_conditionView release];
    [_typeView release];
    [_hotView release];
    [_typeSC release];
    [_hotSC release];
    [_conditionSC release];
    [_hotGategoryView release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [_keyWordTextField release];
    [super dealloc];
}
- (void)setSearchData:(NSDictionary *)dic {
    [_delegeta setSearchArray:dic];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.conditionArray = [NSMutableArray array];
        self.hotArray = [NSMutableArray array];

    }
    return self;
}

#pragma mark
#pragma mark  viewDidLoad
- (void)viewDidLoad
{
    [super viewDidLoad];
    _isHotBool = YES;
    [_conditionSC.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
//    //[self  requestCagetory];
//    {"totalCount":12,"pageNo":1,"pageSize":12,"data":[{"category":"休闲","hotindex":2529},{"category":"穿越","hotindex":900},{"category":"线下活动","hotindex":593},{"category":"腐败","hotindex":97},{"category":"A A 约伴","hotindex":47},{"category":"徒步","hotindex":42},{"category":"登山","hotindex":39},{"category":"摄影","hotindex":29},{"category":"休闲穿越","hotindex":22},{"category":"休闲摄影","hotindex":21},{"category":"旅游","hotindex":20},{"category":"穿越 休闲","hotindex":19}],"success":true,"responseMessage":"success"}
    
//    NSArray *array = @[@{@"category": @"休闲",@"hotindex": [NSNumber numberWithInt:2529]},@{@"category": @"穿越",@"hotindex": [NSNumber numberWithInt:900]},@{@"category": @"线下活动",@"hotindex": [NSNumber numberWithInt:593]},@{@"category": @"腐败",@"hotindex": [NSNumber numberWithInt:97]},@{@"category": @"A A 约伴",@"hotindex": [NSNumber numberWithInt:47]},@{@"category": @"徒步",@"hotindex": [NSNumber numberWithInt:42]},@{@"category": @"登山",@"hotindex": [NSNumber numberWithInt:39]},@{@"category": @"摄影",@"hotindex": [NSNumber numberWithInt:29]}];
//    self.arrayCategory = [NSArray arrayWithArray:array];
    [self  requestCagetory];
    
    [self performSelectorOnMainThread:@selector(requestHotPlaceAction) withObject:nil waitUntilDone:NO];
//    [self requestHotPlaceAction];
}
-(void)requestHotPlaceAction
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTIVITY_GETHOTPLACE];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestHotFinished:) onFailure:@selector(requestHotFailed:) userInfo:nil];
}
- (void)requestHotFinished:(ASIHTTPRequest *)request {
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        [self.view makeToast:LOADING_STRING];
        return;
    }
    
    NSMutableArray *array = [root objectForKey:@"data"];
    NSMutableArray *arrayPlace = [NSMutableArray array];
    for (int i=0; i<array.count; i++) {
        NSMutableArray *placeArr = [NSMutableArray array];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setObject:[[array objectAtIndex:i] objectForKey:@"place"] forKey:@"category"];
        [dic setObject:[[array objectAtIndex:i] objectForKey:@"hotindex"] forKey:@"hotindex"];
        [placeArr addObject:dic];
        [arrayPlace addObjectsFromArray:placeArr];
    }
    [_hotArray addObjectsFromArray:arrayPlace];
    [self loadHotAction];
}

- (void)requestHotFailed:(ASIHTTPRequest *)request
{
}

- (void)requestCagetory {
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTIVITY_CAGETORY];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"GET" parameters:nil delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@", root);
    if(!error) {
        return;
    }
    else {
        
    }
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    NSLog(@"responseString:%@",successString);
    if (![successString isEqualToString:@"1"]) {
        return;
    }
    
    NSArray *array = [root objectForKey:@"data"];
    self.arrayCategory = [NSMutableArray arrayWithArray:array];
    [self loadCagetory];
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
}

#pragma mark
#pragma mark  热门显示
- (void)loadHotAction
{
    self.hotSC.backgroundColor = [UIColor clearColor];
    int row = 0;
    CGFloat fromX = 10.0;
    CGFloat fromY = 5.0;
    CGFloat labelHeight = 20.0;
    CGFloat sepW = 10.0;
    CGFloat sepH = 10.0;
    CGFloat maxWidth = 320.0-10.0;
    CGFloat currentWidth = fromX;
    CGRect frame;
    for (int i=0; i<[_hotArray count]; i++) {
        UILabel *label = [[[UILabel alloc] init] autorelease];
        NSString *string  = [[_hotArray objectAtIndex:i] objectForKey:@"category"];
        label.text = string;
        label.font = SYSTEMFONT(13);
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor clearColor];
        
        CGSize size = [[[_hotArray
                         objectAtIndex:i] objectForKey:@"category"] sizeWithFont:label.font constrainedToSize:CGSizeMake(2000.0, labelHeight) lineBreakMode:NSLineBreakByWordWrapping];
        
        if (currentWidth + size.width + sepW > maxWidth) {
            currentWidth = fromX;
            row ++;
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }else {
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }
        currentWidth = currentWidth + size.width + sepW;
        label.frame = frame;
        UIButton  *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.text = [NSString stringWithFormat:@"%d",i];
        [button setTitleColor:[UIColor colorWithRed:240.0f/255.0f green:96.0f/255.0f blue:0.0f alpha:1.0] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:0];
        [button setBackgroundImage:PNGIMAGE(@"文字框") forState:0];
        int tagNum = [[[_hotArray objectAtIndex:i] objectForKey:@"hotindex"] intValue];
        button.tag = tagNum;
        button.frame = label.frame;
        [button addTarget:self action:@selector(bottonHotClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.hotSC addSubview:button];
        [self.hotSC addSubview:label];
        
        if ( label.frame.origin.y > 90 ) {
            [self.hotSC setContentSize:CGSizeMake(280, label.frame.origin.y+20)];
        }
    }
}


#pragma mark
#pragma mark  类型显示

- (void)loadCagetory {
    self.typeSC.backgroundColor = [UIColor clearColor];
    int row = 0;
    CGFloat fromX = 10.0;
    CGFloat fromY = 5.0;
    CGFloat labelHeight = 20.0;
    CGFloat sepW = 10.0;
    CGFloat sepH = 10.0;
    CGFloat maxWidth = 320.0-10.0;
    CGFloat currentWidth = fromX;
    CGRect frame;
    for (int i=0; i<[_arrayCategory count]; i++) {
        UILabel *label = [[UILabel alloc] init];
        NSString *string  = [[_arrayCategory objectAtIndex:i] objectForKey:@"category"];
        label.text = string;
        label.font = SYSTEMFONT(13);
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor clearColor];
        
        CGSize size = [[[_arrayCategory
                        objectAtIndex:i] objectForKey:@"category"] sizeWithFont:label.font constrainedToSize:CGSizeMake(2000.0, labelHeight) lineBreakMode:NSLineBreakByWordWrapping];
        
        if (currentWidth + size.width + sepW > maxWidth) {
            currentWidth = fromX;
            row ++;
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }else {
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }
        currentWidth = currentWidth + size.width + sepW;
        label.frame = frame;
        UIButton  *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.text = [NSString stringWithFormat:@"%d",i];
        [button setTitleColor:[UIColor colorWithRed:240.0f/255.0f green:96.0f/255.0f blue:0.0f alpha:1.0] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:0];
        [button setBackgroundImage:PNGIMAGE(@"文字框") forState:0];
        int tagNum = [[[_arrayCategory objectAtIndex:i] objectForKey:@"hotindex"] intValue];
        button.tag = tagNum;
        
        button.frame = label.frame;
        [button addTarget:self action:@selector(bottonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.typeSC addSubview:button];
        [self.typeSC addSubview:label];
        
        if ( label.frame.origin.y > 90 ) {
            [self.typeSC setContentSize:CGSizeMake(280, label.frame.origin.y+20)];
        }
    }
}

#pragma mark
#pragma mark  点击类型的按钮

- (void)bottonClick:(id)sender {
    _isHotBool = NO;
    UIButton *btn = (UIButton *)sender;
    if (!btn) {
        return;
    }
    for(int i = 0; i < [_arrayCategory count]; i++){
        UIButton *but = (UIButton *)[self.view viewWithTag:[[[_arrayCategory objectAtIndex:i] objectForKey:@"hotindex"] intValue]];
        
        if (but.tag == btn.tag) {
            NSLog(@"but:%d",but.tag);
            BOOL has = NO;
            for (NSDictionary *dic in _conditionArray) {
                if ([[dic objectForKey:@"hotindex"] intValue] == but.tag) {
                    has = YES;
                    break;
                }
            }
            if (has) {
                NSLog(@"已经添加过了");
            }else {
                [_conditionArray addObject:[_arrayCategory objectAtIndex:i]];
                [self loadCondition];
            }

            return;
        } else {
        }
    }
    
}


- (void)bottonHotClick:(id)sender {
    
    _isHotBool = YES;
    UIButton *btn = (UIButton *)sender;
    if (!btn) {
        return;
    }
    for(int i = 0; i < [_hotArray count]; i++){
        UIButton *but= (UIButton *)[self.view viewWithTag:[[[_hotArray objectAtIndex:i] objectForKey:@"hotindex"] intValue]];
        if (but.tag == btn.tag) {
            NSLog(@"but:%d",but.tag);
            BOOL has = NO;
            for (NSDictionary *dic in _conditionArray) {
                if ([[dic objectForKey:@"hotindex"] intValue] == but.tag) {
                    has = YES;
                    break;
                }
            }
            if (has) {
                NSLog(@"已经添加过了");
            }else {
                [_conditionArray addObject:[_hotArray objectAtIndex:i]];
                [self loadCondition];
            }
            
            return;
            
        } else {
        }
    }
    
}


#pragma mark *********布局条件界面

- (void)loadCondition {
    [_conditionSC.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    int row = 0;
    CGFloat fromX = 10.0;
    CGFloat fromY = 5.0;
    CGFloat labelHeight = 20.0;
    CGFloat sepW = 10.0;
    CGFloat sepH = 10.0;
    CGFloat maxWidth = 320.0-10.0;
    CGFloat currentWidth = fromX;
    CGRect frame;
    for (int i=0; i<[_conditionArray count]; i++) {
        UILabel *label = [[UILabel alloc] init];
        NSString *string = [[_conditionArray objectAtIndex:i] objectForKey:@"category"];
        label.text = string;
        label.font = SYSTEMFONT(13);
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor whiteColor];

        CGSize size = [[[_conditionArray
                         objectAtIndex:i] objectForKey:@"category"] sizeWithFont:label.font constrainedToSize:CGSizeMake(2000.0, labelHeight) lineBreakMode:NSLineBreakByWordWrapping];
        
        if (currentWidth + size.width + sepW > maxWidth) {
            currentWidth = fromX;
            row ++;
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }else {
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }
        currentWidth = currentWidth + size.width + sepW;
        label.frame = frame;
        UIButton  *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.text = [NSString stringWithFormat:@"%d",i];
        [button setBackgroundImage:PNGIMAGE(@"删除") forState:0];
        [button setTitleColor:[UIColor colorWithRed:240.0f/255.0f green:96.0f/255.0f blue:0.0f alpha:1.0] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:0];
        int tagNum = [[[_conditionArray objectAtIndex:i] objectForKey:@"hotindex"] intValue];
        button.tag = tagNum;
        NSLog(@"buttontag%ld",(long)button.tag);
        button.frame = label.frame;
        
        UIButton *delButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [delButton setImage:PNGIMAGE(@"删除1") forState:0];
        delButton.frame = CGRectMake(X(button)+WIDTH(label)-5,Y(button)-5, 14, 14);
       
        [button addTarget:self action:@selector(deleteCondition:) forControlEvents:UIControlEventTouchUpInside];
        [self.conditionSC addSubview:button];
        [self.conditionSC addSubview:label];
         [self.conditionSC addSubview:delButton];
        
        if ( label.frame.origin.y > 90 ) {
            [self.conditionSC setContentSize:CGSizeMake(280, label.frame.origin.y+20)];
        }
    }
}

#pragma mark
#pragma mark   把热门的条件添加到搜索条件里
- (void)loadHotCondition {
    [_conditionSC.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    int row = 0;
    CGFloat fromX = 10.0;
    CGFloat fromY = 5.0;
    CGFloat labelHeight = 20.0;
    CGFloat sepW = 10.0;
    CGFloat sepH = 10.0;
    CGFloat maxWidth = 320.0-10.0;
    CGFloat currentWidth = fromX;
    CGRect frame;
    for (int i=0; i<[_conditionArray count]; i++) {
        
        UILabel *label = [[UILabel alloc] init];
        NSString *string = [[_conditionArray objectAtIndex:i] objectForKey:@"place"];
        label.text = string;
        label.font = SYSTEMFONT(13);
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor whiteColor];
        
        CGSize size = [[[_conditionArray
                         objectAtIndex:i] objectForKey:@"place"] sizeWithFont:label.font constrainedToSize:CGSizeMake(2000.0, labelHeight) lineBreakMode:NSLineBreakByWordWrapping];
        
        if (currentWidth + size.width + sepW > maxWidth) {
            currentWidth = fromX;
            row ++;
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }else {
            frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
        }
        currentWidth = currentWidth + size.width + sepW;
        label.frame = frame;
        UIButton  *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.text = [NSString stringWithFormat:@"%d",i];
        [button setBackgroundImage:PNGIMAGE(@"文字框") forState:0];
        [button setTitleColor:[UIColor colorWithRed:240.0f/255.0f green:96.0f/255.0f blue:0.0f alpha:1.0] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:0];
        int tagNum = [[[_conditionArray objectAtIndex:i] objectForKey:@"hotindex"] intValue];
        button.tag = tagNum;
        NSLog(@"buttontag%ld",(long)button.tag);
        button.frame = label.frame;
        [button addTarget:self action:@selector(deleteCondition:) forControlEvents:UIControlEventTouchUpInside];
        [self.conditionSC addSubview:button];
        [self.conditionSC addSubview:label];
        
        if ( label.frame.origin.y > 90 ) {
            [self.conditionSC setContentSize:CGSizeMake(280, label.frame.origin.y+20)];
        }
    }
}


int row = 0;
CGFloat fromX = 10.0;
CGFloat fromY = 10.0;
CGFloat labelHeight = 20.0;
CGFloat sepW = 10.0;
CGFloat sepH = 10.0;
CGFloat maxWidth = 320.0-10.0;
CGFloat currentWidth = 10.0;
CGRect frame;

- (void) drawLabelCondition:(int)num {
    NSString *stringNum = [NSString stringWithFormat:@"%d",num];
    NSString *string1;
    if (_conditionArray.count != 0) {
        for (int i = 0; i < [_conditionArray count]; i++) {
            string1 = [[[_conditionArray objectAtIndex:i] objectForKey:@"hotindex"] stringValue];
            if ([string1 isEqualToString:stringNum]) {
                NSLog(@"相等不添加");
                return;
            }
        }
    }
    UILabel *label = [[UILabel alloc] init];
    NSString *labelString = [NSString stringWithFormat:@"%d",num];
    for (int i=0; i<_arrayCategory.count; i++) {
        NSString *string = [[[_arrayCategory objectAtIndex:i] objectForKey:@"hotindex"] stringValue];
        if ([string isEqualToString:labelString]) {
            NSLog(@"找到了找到了");
            NSString *string  = [[_arrayCategory objectAtIndex:i] objectForKey:@"category"];
            label.text = string;
            label.font = [UIFont systemFontOfSize:20.0];
            label.textColor = [UIColor blackColor];
            label.backgroundColor = [UIColor clearColor];

            CGSize size = [[[_arrayCategory objectAtIndex:i] objectForKey:@"category"] sizeWithFont:label.font constrainedToSize:CGSizeMake(2000.0, 20) lineBreakMode:NSLineBreakByWordWrapping];
            
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            
            if (currentWidth + size.width + sepW > maxWidth) {
                currentWidth = fromX;
                row ++;
                frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
                
            }else {
                frame = CGRectMake(currentWidth, fromY + row*(sepH+labelHeight), size.width, labelHeight);
            }
            currentWidth = currentWidth + size.width + sepW;
            label.frame = frame;
            button.frame = frame;
            [button setBackgroundColor:[UIColor clearColor]];
            button.tag = num;
            [button addTarget:self action:@selector(deleteCondition:) forControlEvents:UIControlEventTouchUpInside];
            [_conditionArray addObject:[_arrayCategory objectAtIndex:i]];
            [self.conditionSC addSubview:button];
//            [self.conditionSC addSubview:label];

        }
    }
    
    if (label.frame.origin.y > 5 ) {
        [self.conditionSC setContentSize:CGSizeMake(currentWidth, label.frame.origin.y)];
    }
    
}
- (void)deleteCondition:(UIButton *)button {
    NSLog(@"%ld",(long)button.tag);
    for (int i=0; i<_conditionArray.count; i++) {
        if ([[((NSDictionary *)[_conditionArray objectAtIndex:i]) objectForKey:@"hotindex"] intValue] == button.tag) {
            [_conditionArray removeObjectAtIndex:i];
            i--;
        }
    }
    
    [self loadCondition];
    return;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark
#pragma mark    条件查询
- (IBAction)searchAction:(id)sender {
    
//    if (_conditionArray == nil || _conditionArray.count == 0) {
//        [[iToast makeToast:@"搜索条件不能为空"] show];
//        return;
//    }

    NSMutableDictionary *common = [NSMutableDictionary dictionary];
    NSMutableArray *conArray = [NSMutableArray array]; //条件数组
    NSMutableDictionary *conditionDic = [NSMutableDictionary dictionary]; //最后加到字典里去。组成想要的格式
    
    [common setObject:_keyWordTextField.text forKey:@"keywords"];
    for (int i = 0; i < _conditionArray.count; i ++) {
        NSMutableDictionary *dicCategory = [NSMutableDictionary dictionary];
        NSDictionary *dic = [_conditionArray objectAtIndex:i];
        NSString *string = [dic objectForKey:@"category"];
        [dicCategory setObject:string forKey:@"categroy"];
        [conArray addObject:dicCategory];
        
    }
    [conArray addObject:common];
    [conditionDic setObject:conArray forKey:@"condition"];
    NSLog(@"dic%@", conditionDic);

    //开始提交数据
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTIVITY_SEARCH];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:urlString]];
    NSString *sbreq = [JSONFunction jsonStringWithNSDictionary:conditionDic];
    [request setPostValue:sbreq  forKey:@"condition"];
    MBPHUD_SHOW;
    [request setCompletionBlock:^{
        MBPHUD_HIDDEN;
        NSDictionary *root = [JSONFunction jsonObjectWithData:request.responseData];
        NSLog(@"root:%@",root);
        NSString *messateStr = [root objectForKey:@"responseMessage"];
        NSLog(@"responseMessage：%@",messateStr);
        [_delegeta  setSearchData:root];
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }];
    [request setFailedBlock:^{
        MBPHUD_HIDDEN;
        
    }];
    [request startAsynchronous];
    
//    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
//    [httpClient asynchronousRequest:urlString method:@"POST" parameters:conditionDic delegate:self onSuccess:@selector(requestSerchFinished:) onFailure:@selector(requestSerchFailed:) userInfo:nil];
//    MBPHUD_SHOW;


}

//- (void)requestSerchFinished:(ASIHTTPRequest *)request {
//    MBPHUD_HIDDEN;
//    NSError *error;
//    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
//    NSLog(@"ROOT=%@", root);
//    if(!error) {
//        return;
//    }
//    else {
//        
//    }
//    
//    NSString *successString = [root objectForKey:@"success"];
//    if (![successString isEqualToString:@"1"]) {
//        return;
//    }
//}
//
//- (void)requestSerchFailed:(ASIHTTPRequest *)request
//{
//    MBPHUD_HIDDEN;
//}


-(IBAction)textFiledReturnEditing:(id)sender {
    [sender resignFirstResponder];
}


@end
