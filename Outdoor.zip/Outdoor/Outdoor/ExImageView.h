//
//  ExImageView.h
//  uiviewtest
//
//  Created by apple on 13-1-11.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExImageView : UIImageView
{
}
@property (nonatomic, retain) NSObject	*displayHost;
@property (nonatomic, assign) SEL		imageDidTouched;
@property (nonatomic, assign) SEL		imageDidTouch;
@property(nonatomic, assign) BOOL m_tag;
@end
