//
//  PartakeViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ASIFormDataRequest.h"

@interface PartakeViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,ASIHTTPRequestDelegate>
- (IBAction)back:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *butApply;
@property (retain, nonatomic) IBOutlet UITableView *tableViewPartake;
@property (retain, nonatomic) IBOutlet UIButton *butRecord;
@property (retain, nonatomic) IBOutlet UIView *mainView;


@end
