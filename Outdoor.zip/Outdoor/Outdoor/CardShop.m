//
//  CardShop.m
//  Outdoor
//
//  Created by WangKaifeng on 14-3-5.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "CardShop.h"

#define ktitleKey @"title"
#define ktimeKey @"timeString"
#define knumtKey @"numString"


@implementation CardShop

@synthesize timeString;
@synthesize numString;
@synthesize title;

#pragma mark-NSCoding
-(void)encodeWithCoder:(NSCoder *)aCoder{
    
    
    [aCoder encodeObject:title forKey:ktitleKey];
    [aCoder encodeObject:numString forKey:knumtKey];
    [aCoder encodeObject:timeString forKey:ktimeKey];
}


-(id)initWithCoder:(NSCoder *)aDecoder{
    
    if (self == [super init]) {
        title =  [aDecoder decodeObjectForKey:ktitleKey];
        numString = [aDecoder decodeObjectForKey:knumtKey];
        timeString =  [aDecoder decodeObjectForKey:ktimeKey];
    }
    
    return self;
}



#pragma mark-NSCopying
-(id)copyWithZone:(NSZone *)zone{
    CardShop *copy = [[[self class] allocWithZone:zone] init];
    copy.title = [self.title copyWithZone:zone];
    copy.numString = [self.numString copyWithZone:zone];
    copy.timeString = [self.timeString copyWithZone:zone];
    return copy;
}
@end
