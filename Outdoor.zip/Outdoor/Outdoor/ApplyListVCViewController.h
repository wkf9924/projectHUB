//
//  ApplyListVCViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-6.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Api.h"
@interface ApplyListVCViewController : UIViewController <ASIHTTPRequestDelegate,UIAlertViewDelegate>

@property (nonatomic,retain) NSString *tidStirng;
@property (nonatomic,retain) NSMutableArray *arrayApplyList;
@end
