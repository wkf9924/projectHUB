//
//  LoginViewController.m
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "LoginViewController.h"
#import "Api.h"
#import "HCHTTPClient.h"
#import "ASIHTTPRequest.h"
#import "MBProgressHUD.h"
#import "RegistViewController.h"
#import "LoginSuccessiewController.h"
#import "MessageApplyVC.h"

@interface LoginViewController ()

- (IBAction)qqLogin:(id)sender;
@end


@implementation LoginViewController

- (void)dealloc
{
    [_username release];
    [_password release];
    for (ASIFormDataRequest *request in [ASIFormDataRequest sharedQueue].operations) {
        [request clearDelegatesAndCancel];
    }
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

SWIPE_RIGHT_MONTH;
- (void)viewDidLoad
{
    [super viewDidLoad];
    [_password setSecureTextEntry:YES];
    SWIPE_RIGHT;
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)login:(id)sender {
    [self loginAction];
}

- (IBAction)registerAction:(id)sender {
    RegistViewController *rg = [[RegistViewController alloc] initWithNibName:Nil bundle:nil];
    [self.navigationController pushViewController:rg animated:YES];
}

- (void)loginAction
{

    if ([_password.text isEqualToString:@""] || [_username.text isEqualToString:@""]) {
        [[iToast makeToast:@"用户名密码不能为空！"] show];
        return;
    }
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:_username.text forKey:@"username"];
    [common setObject:_password.text forKey:@"password"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,USER_LOGIN];
    HCHTTPClient *httpClient = [[[HCHTTPClient alloc ] init] autorelease];
    [httpClient asynchronousRequest:urlString method:@"POST" parameters:common delegate:self onSuccess:@selector(requestFinished:) onFailure:@selector(requestFailed:) userInfo:nil];
    MBPHUD_SHOW;
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    MBPHUD_HIDDEN;
    NSError *error;
    NSDictionary *root = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"ROOT=%@",root);
    if(!error) {
        return;
    }
    else {
    }
    NSString *responseString = [root objectForKey:@"responseMessage"];
    NSLog(@"responseString:%@",responseString);
    NSString *successString = [[root objectForKey:@"success"] stringValue];
    if (![successString isEqualToString:@"1"]) {
        
        [[iToast makeToast:@"用户名或密码错误"] show];
        return;
    } else {
         [[iToast makeToast:@"登录成功"] show];
    }

    NSString *stringType = [Single sharedInstance].string;
    
    if ([stringType isEqualToString:@"xiangQing"] || [stringType isEqualToString:@"shoucang"]) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    if ([stringType isEqualToString:@"wo"]) { //如果是从我界面过来的
        LoginSuccessiewController *ls = [[LoginSuccessiewController alloc] initWithNibName:@"LoginSuccessiewController" bundle:nil];
        [self.navigationController pushViewController:ls animated:YES];
        NSLog(@"login");
    }
    if ([stringType isEqualToString:@"shop"]) {
        ShoopingCardViewController *shop = [[[ShoopingCardViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        [self.navigationController pushViewController:shop animated:YES];
    }
    if ([stringType isEqualToString:@"shouCang"]) {
        
        CollectViewController *coll = [[[CollectViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        [self.navigationController pushViewController:coll animated:YES];
    }
    if ([stringType isEqualToString:@"xiaoxi"]) {
        MessageApplyVC  *chatView = [[[MessageApplyVC alloc] init] autorelease];
        [self.navigationController pushViewController:chatView animated:YES];
    }

    
    NSDictionary *dicc = [root objectForKey:@"data"];
    
    NSString *tokenStr = [dicc objectForKey:@"token"];
    // 保存token
    [Util saveToken:tokenStr];
    //保存登录成功后的信息
    [Util setLogin:dicc];
    //设置登录状态为YES
    [Util setLoginOk];
    [ApplicationDelegate connect];
//
//    [self.navigationController popViewControllerAnimated:YES];
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    MBPHUD_HIDDEN;
    ALERT_DATA;
    
}

- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 *	@brief	登录
 */
- (IBAction)qqLogin:(id)sender {
    
    id<ISSAuthOptions> authOptions = [ShareSDK authOptionsWithAutoAuth:YES
                                                         allowCallback:YES
                                                         authViewStyle:SSAuthViewStyleFullScreenPopup
                                                          viewDelegate:nil
                                               authManagerViewDelegate:nil];
    
    //在授权页面中添加关注官方微博
    [authOptions setFollowAccounts:[NSDictionary dictionaryWithObjectsAndKeys:
                                    [ShareSDK userFieldWithType:SSUserFieldTypeName value:@"ShareSDK"],
                                    SHARE_TYPE_NUMBER(ShareTypeSinaWeibo),
                                    [ShareSDK userFieldWithType:SSUserFieldTypeName value:@"ShareSDK"],
                                    SHARE_TYPE_NUMBER(ShareTypeTencentWeibo),
                                    nil]];
    
    [ShareSDK getUserInfoWithType:ShareTypeTencentWeibo
                      authOptions:authOptions
                           result:^(BOOL result, id<ISSPlatformUser> userInfo, id<ICMErrorInfo> error) {
                               if (result)
                               {
                                   NSLog(@"%@",[userInfo nickname]);
                                   NSLog(@"userinfo=%@",[userInfo uid]);
                                   //取前14个
                                   NSString *uid = [[userInfo uid] substringToIndex:14];
                                   NSLog(@"uid:%@",uid);
                                   //开始注册
                                   [self qqRegistAction:uid];

                               }
                               NSLog(@"%d:%@",[error errorCode], [error errorDescription]);
                           }];
    
}


- (void)qqRegistAction:(NSString *)stringUid {
    
    
    NSDictionary *common = @{@"username":stringUid, @"password":@"123456"};
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:common];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,REGISTER_USER];
    MBPHUD_SHOW;
    [DataRequest dataWithDic:dic andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        
        NSLog(@"responseString:%@",requestStr);
        MBPHUD_HIDDEN;
//        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSDictionary *root = [JSONFunction jsonObjectWithNSString:requestStr];
        NSLog(@"qq授权后开始登陆返回结果：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        NSString *requestString = [root objectForKey:@"responseMessage"];
        if (![successString isEqualToString:@"1"]) {
            
            //如果返回是“该账号已被注册”，直接就登陆
            if ([requestString isEqualToString:@"该帐号已被注册"]) {
                [self qqLoginAction:stringUid];
                return;
            }
            [[iToast makeToast:@"用户名或密码错误"] show];
            return;
        } else {
            [self qqLoginAction:stringUid];
        }
        
    }];

}


- (void)qqLoginAction:(NSString *)stringId {
    
    NSDictionary *common = @{@"username":stringId, @"password":@"123456"};
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:common];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,USER_LOGIN];
    MBPHUD_SHOW;
    [DataRequest dataWithDic:dic andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        
        MBPHUD_HIDDEN;
        //        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSDictionary *root = [JSONFunction jsonObjectWithNSString:requestStr];
        NSLog(@"qq授权后开始登陆返回结果：%@", root);
        
        NSString *responseString = [root objectForKey:@"responseMessage"];
        NSLog(@"responseString:%@",responseString);
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if (![successString isEqualToString:@"1"]) {
            [[iToast makeToast:@"用户名或密码错误"] show];
            
            [ShareSDK cancelAuthWithType:ShareTypeTencentWeibo];
            [ShareSDK cancelAuthWithType:ShareTypeSinaWeibo];
            return;
        } else {
            NSDictionary *dicc = [root objectForKey:@"data"];
            NSString *tokenStr = [dicc objectForKey:@"token"];
            // 保存token
            [Util saveToken:tokenStr];
            //保存登录成功后的信息
            [Util setLogin:dicc];
            //设置登录状态为YES
            [Util setLoginOk];
            [ApplicationDelegate connect];
            [self.navigationController popViewControllerAnimated:YES];
            [[iToast makeToast:@"登录成功"] show];

        }
        
    }];

}


@end
