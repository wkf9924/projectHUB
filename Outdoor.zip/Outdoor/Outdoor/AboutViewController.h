//
//  AboutViewController.h
//  Outdoor
//
//  Created by Robin on 14-2-11.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController
- (IBAction)back:(id)sender;

@end
