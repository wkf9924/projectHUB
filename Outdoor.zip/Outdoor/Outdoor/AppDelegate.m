//
//  AppDelegate.m
//  Outdoor
//
//  Created by Robin on 14-1-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "AppDelegate.h"
#import "MyViewController.h"
#import "Api.h"
#import <ShareSDK/ShareSDK.h>
#import "WXApi.h"
#import "UIFunction.h"
#import "DDLog.h"
#import "DDTTYLogger.h"
#import "Utility.h"
#import <CFNetwork/CFNetwork.h>
#import "ChatViewController.h"
#import "KGStatusBar.h"
#import <math.h>
#import <AudioToolbox/AudioToolbox.h>
//#import <WTStatusBar/WTStatusBar.h>
#import "WTStatusBar.h"
#import "WQPlaySound.h"

//#if DEBUG
//static const int ddLogLevel = LOG_LEVEL_VERBOSE;
//#else
//static const int ddLogLevel = LOG_LEVEL_INFO;
//#endif

@interface AppDelegate ()


@property (nonatomic, strong) UIWindow * statusWindow;
@property (nonatomic, strong) UILabel * statusLabel;

- (void) dismissStatus;

@end

@implementation AppDelegate


@synthesize xmppStream,xmppReconnect,xmppPubsubManager,myJID,xmppPassword;
@synthesize netWorkReachability;



- (void)dealloc {
    [self teardownStream];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
//    //设置电池状态栏
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    [WXApi registerApp:@"wx3d4f6fc7da88940a"];
    //    [QQApi registerPluginWithId:@"QQC2956C2E"];
    [ShareSDK registerApp:@"4ce8c7640b"];
    
    [ShareSDK connectWeChatWithAppId:@"wx3d4f6fc7da88940a" wechatCls:[WXApi class]];
    
    [ShareSDK connectSinaWeiboWithAppKey:@"1923335646" appSecret:@"e341f178b4d867598465d7774d9bc4b5" redirectUri:@"http://www.bshare.cn"];//添加新浪微博应用
    
    [ShareSDK connectTencentWeiboWithAppKey:@"801173916" appSecret:@"0f2eb888d75cfb5c1aa80ff9884ae85b" redirectUri:@"http://127.0.0.1/success.html" wbApiCls:nil];//添加腾讯微博应用
//    [DDLog addLogger:[DDTTYLogger sharedInstance]];
    
    // Setup the XMPP stream
//    [Utility conversionSql1:MESSAGETABLE];
    
    [self setupStream];
//[[ExXmpp shareInstance:YES] initData];
    return YES;
}


//点击HOME 后 先走这个
- (void)applicationWillResignActive:(UIApplication *)application
{

}

//点几HOME 后 在走这个
- (void)applicationDidEnterBackground:(UIApplication *)application
{

}

- (void)applicationWillEnterForeground:(UIApplication *)application
{

}

//解锁时进入app 或者是点击home键后，再次点击app的时候
- (void)applicationDidBecomeActive:(UIApplication *)application
{
//    [[ExXmpp shareInstance:YES] returnCconnected];
    [self connect];
    NSLog(@"%@",THIS_METHOD);
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    NSLog(@"%@",THIS_METHOD);
}



#pragma mark - View Action

#pragma mark -
#pragma mark Application Info

+ (id) getAppdelegate {
    AppDelegate *app = (AppDelegate*) [[UIApplication sharedApplication] delegate];
	return app;
}


#pragma mark -
#pragma mark Xmpp method


- (void)setupStream
{
	NSAssert(xmppStream == nil, @"Method setupStream invoked multiple times");
	xmppStream = [[XMPPStream alloc] init];
#if !TARGET_IPHONE_SIMULATOR
	{
		xmppStream.enableBackgroundingOnSocket = YES;
	}
#endif

	xmppReconnect = [[XMPPReconnect alloc] init];
    xmppPubsubManager = [[XMPPPubSub alloc] init];
	[xmppReconnect         activate:xmppStream];
    [xmppPubsubManager activate:xmppStream];
	[xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppStream setHostName:@"xinhuwai.com"];
    [xmppStream setHostPort:7082];
	
}

- (void)teardownStream
{
	[xmppStream removeDelegate:self];
	[xmppReconnect         deactivate];
    [xmppPubsubManager deactivate];
	[xmppStream disconnect];
	xmppStream = nil;
	xmppReconnect = nil;
    xmppPubsubManager = nil;
}

//发送在线状态
- (void)goOnline
{
	XMPPPresence *presence = [XMPPPresence presence];
	[[self xmppStream] sendElement:presence];
}

//发送下线状态
- (void)goOffline
{
	XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
	[[self xmppStream] sendElement:presence];
}

- (BOOL)connect
{

	if (![xmppStream isDisconnected]) {
        //发送在线
        [self goOnline];
		return YES;
	}
    
    if (![Util isLogin]) {
        return NO;
    }
    NSDictionary *userName = [Util getLoginData];
    NSMutableString *jidString = [userName objectForKey:@"userName"];

	NSString *myJIDString = [jidString stringByAppendingString:XMPP_JID];
    xmppPassword =@"123456";
	
	if (myJIDString == nil || xmppPassword == nil) {
		return NO;
	}
//	[xmppStream setMyJID:[XMPPJID jidWithString:myJIDString]];
    [self setMyJID:[XMPPJID jidWithString:myJIDString resource:@"iOS"]];
    [xmppStream setMyJID:myJID];


	NSError *error = nil;
	if (![xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error connecting"
		                                                    message:@"See console for error details."
		                                                   delegate:nil
		                                          cancelButtonTitle:@"Ok"
		                                          otherButtonTitles:nil];
		[alertView show];
        
		NSLog(@"Error connecting: %@", error);
        
		return NO;
	}
    
	return YES;
}

- (void)disconnect
{
	[self goOffline];
	[xmppStream disconnect];
}


//解锁时连接。
-(void)returnCconnected
{
    if ([xmppStream isDisconnected])
    {
//        NSLog(@"连接服务器");
        //连接服务器
        NSError *error = nil;
        if (![xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error])
        {
            [[iToast makeToast:@"XMPP服务器连接失败！"] show];
        }
    }
    else
    {
        NSLog(@"发送在线");
        [self goOnline];
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark XMPPStream Delegate
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//- (void)xmppStream:(XMPPStream *)sender socketDidConnect:(GCDAsyncSocket *)socket
//{
//	DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
//}
//
//- (void)xmppStream:(XMPPStream *)sender willSecureWithSettings:(NSMutableDictionary *)settings
//{
//	DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
//	
//	if (_allowSelfSignedCertificates)
//	{
//		[settings setObject:[NSNumber numberWithBool:YES] forKey:(NSString *)kCFStreamSSLAllowsAnyRoot];
//	}
//	
//	if (_allowSSLHostNameMismatch)
//	{
//		[settings setObject:[NSNull null] forKey:(NSString *)kCFStreamSSLPeerName];
//	}
//	else
//	{
//		NSString *expectedCertName = [xmppStream.myJID domain];
//        
//		if (expectedCertName)
//		{
//			[settings setObject:expectedCertName forKey:(NSString *)kCFStreamSSLPeerName];
//		}
//	}
//}

- (void)xmppStreamDidSecure:(XMPPStream *)sender
{
//	DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

//连接服务器
- (void)xmppStreamDidConnect:(XMPPStream *)sender
{
	NSLog(@"%@: %@", THIS_FILE, THIS_METHOD);
	
	_isXmppConnected = YES;
	
	NSError *error = nil;
	
	if (![[self xmppStream] authenticateWithPassword:@"123456" error:&error])
	{
		NSLog(@"Error authenticating: %@", error);
	}
}

//验证通过
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
	NSLog(@"验证通过->%@: %@", THIS_FILE, THIS_METHOD);
    //登录成功  订阅节点
    [_delegate subscription];
    xmppPubsubManager = [xmppPubsubManager initWithServiceJID:[XMPPJID jidWithString:@"pubsub.xinhuwai"] dispatchQueue:dispatch_get_main_queue()];
	[self goOnline];
}

- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error
{
	NSLog(@"%@: %@", THIS_FILE, THIS_METHOD);
}

- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq
{
    
	NSLog(@"收到iq-》%@: %@", THIS_FILE, THIS_METHOD);
    
	/**判断审核通过的IQ，如果当前运行的Controller是消息界面，调用刷新数据Delegate(需要自定义)
     *如果不在当前运行的Controller，alertview提示用户审批通过。
     *然后读取web server的api，获取群组订阅。    
     [xmppPubsubManager subscribeToNode:]
     **/

    NSLog(@"didReceiveIQ: %@",iq.description);
    NSLog(@"iq: %@",iq.childElement);
    //判断Approved iq
	return YES;

}


//发送消息
- (void)sendMessage:(NSString *)body to:(NSString *)to subject:(NSString *)subject
{
    //me发的
    NSString *nickName = [NSString stringWithFormat:@"%@", [myJID user]];
    //发送的内容
    NSString *nickMessage = [NSString stringWithFormat:@"%@", body];
    //节点名字，作为表名
    NSString *nickJid = [NSString stringWithFormat:@"%@", subject];
    //创建节点。
    NSDictionary *msg = @{@"nickName": nickName, @"nickMessage":nickMessage, @"nickJid":nickJid};
    
    //把对象转JSON

    NSString *jsonTotal = [JSONFunction jsonStringWithNSDictionary:msg];
    
    //生成<body>文档
    NSXMLElement *bodyString = [NSXMLElement elementWithName:@"body"];
    [bodyString setStringValue:jsonTotal];
    
    //生成XML消息文档
    NSXMLElement *mes = [NSXMLElement elementWithName:@"message"];
    
    //消息类型
    [mes addAttributeWithName:@"type" stringValue:@"chat"];
    
    //发送给谁
    [mes addAttributeWithName:@"to" stringValue:to];
    
    //由谁发送
    [mes addAttributeWithName:@"from" stringValue:[myJID bare]];
    
    //组合
    [mes addChild:bodyString];
    NSLog(@"发出的消息：%@", mes);
    
    NSString *dataString = [DateUtil dateToString:[NSDate date] withFormat:@"yy-MM-dd HH:mm"];
    
   
    NSString *isyou = [NSString stringWithFormat:@"%d",1];

    //保存数据库
    NSArray *paramarray = [NSArray arrayWithObjects:nickName, nickMessage, dataString, isyou, nil];
    NSString *creat_book = STRING_FORMAT_INT(@"INSERT INTO %@ (toName, message,data,isSelf) VALUES (?, ?, ?,?)", nickJid);
    [[SQLiteOperation shareDB] dealData:creat_book paramArray:paramarray];

    //发送消息
    [xmppStream sendElement:mes];
}


//收到消息   活动审核通过后也会接受的
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message
{
	NSLog(@"message:%@ \n %@: %@", message, THIS_FILE, THIS_METHOD);
    
     [WTStatusBar setStatusText:@"有新消息" timeout:2.0 animated:YES];
    WQPlaySound *sound = [[[WQPlaySound alloc]initForPlayingSystemSoundEffectWith:@"Tock" ofType:@"aiff"] autorelease];
    [sound play];
    
    if ([message isChatMessageWithBody])
	{
		NSString *body = [[message elementForName:@"body"] stringValue];
        //取出body中的json转换成 dic
//        NSDictionary *bodyDic = [JSONFunction jsonObjectWithNSString:body];
        
        //发送消息调用消息viewController
        [_delegate sendMassage:body isSelf:NO];

	}
}

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
//	DDLogVerbose(@"%@: %@ - %@", THIS_FILE, THIS_METHOD, [presence fromStr]);
    
    NSLog(@"%@: %@ - %@", THIS_FILE, THIS_METHOD, [presence fromStr]);
}

- (void)xmppStream:(XMPPStream *)sender didReceiveError:(id)error
{
//	DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    NSLog(@"%@: %@", THIS_FILE, THIS_METHOD);
    /**
     如果不是正常推出，如果网络存在时，开一个现成来循环检测，防止掉线
     **/
}

//服务器踢掉连接，处理重连。
- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error
{
	NSLog(@"%@: %@", THIS_FILE, THIS_METHOD);
	
	if (!_isXmppConnected)
	{
		NSLog(@"Unable to connect to server. Check xmppStream.hostName");
	}
}



/**
 * @brief 在状态栏显示 一些Log
 *
 * @param string 需要显示的内容
 * @param duration  需要显示多长时间
 */
- (void) showStatusWithText:(NSString *) string duration:(NSTimeInterval) duration {
    
//    AppDelegate * delegate = (AppDelegate *)[self getAppdelegate];
    AppDelegate *delegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    
    delegate.statusLabel.text = string;
    [delegate.statusLabel sizeToFit];
    CGRect rect = [UIApplication sharedApplication].statusBarFrame;
    CGFloat width = delegate.statusLabel.frame.size.width;
    CGFloat height = rect.size.height;
    rect.origin.x = rect.size.width - width - 5;
    rect.size.width = width;
    delegate.statusWindow.frame = rect;
    delegate.statusWindow.backgroundColor = [UIColor blackColor];
    delegate.statusLabel.frame = CGRectMake(0,50, width, height);
    
    if (duration < 1.0) {
        duration = 1.0;
    }
    if (duration > 4.0) {
        duration = 4.0;
    }
    [delegate performSelector:@selector(dismissStatus) withObject:nil afterDelay:duration];
}

/**
 * @brief 干掉状态栏文字
 */
- (void) dismissStatus {
    CGRect rect = self.statusWindow.frame;
    rect.origin.y -= rect.size.height;
    [UIView animateWithDuration:0.5 animations:^{
        self.statusWindow.frame = rect;
    }];
}


@end
