
//
//  ApplyListCell.m
//  Outdoor
//
//  Created by WangKaifeng on 14-3-11.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "ApplyListCell.h"

@implementation ApplyListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_titleName release];
    [_title2 release];
    [_title3 release];
    [_title4 release];
    [_title5 release];
    [_delBtn release];
    [super dealloc];
}
@end
