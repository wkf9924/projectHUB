//
//  MyInfoViewController.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "MyInfoViewController.h"
#import "Api.h"
@interface MyInfoViewController ()
@property (retain, nonatomic) IBOutlet UITextField *userNameTextField;
@property (retain, nonatomic) IBOutlet UITextField *sexTextField;
@property (retain, nonatomic) IBOutlet UITextField *AccountTextField;
@property (retain, nonatomic) IBOutlet UITextField *qqTextField;
- (IBAction)back:(id)sender; //返回
- (IBAction)uploadImage:(id)sender; //更新图片
- (IBAction)textFiledReturnEditing:(id)sender; //隐藏键盘
- (IBAction)backgroundTap:(id)sender; //隐藏键盘
- (IBAction)submit:(id)sender; //提交修改数据
@end

@implementation MyInfoViewController

- (void)dealloc {
    [_AccountTextField release];
    [_userNameTextField release];
    [_sexTextField release];
    [_qqTextField release];
    [super dealloc];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    SWIPE_RIGHT;
    [self showMyInfoAction];
    // Do any additional setup after loading the view from its nib.
}
SWIPE_RIGHT_MONTH;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)uploadImage:(id)sender {
}

- (IBAction)backgroundTap:(id)sender {
    [_sexTextField resignFirstResponder];
    [_AccountTextField resignFirstResponder];
    [_userNameTextField resignFirstResponder];
}

#pragma mark
#pragma mark 提交修改参数
- (IBAction)submit:(id)sender {
    NSString *stringSex;
    
    if ([_userNameTextField.text isEqualToString:@""] || [_sexTextField.text isEqualToString:@""]) {
        [[iToast makeToast:@"请填写完整信息"] show];
        return;
    }
    
    NSString *uidString = STRING_FORMAT_INT(@"%d", [[[Util getLoginData] objectForKey:@"uid"] integerValue]);
    if ([_sexTextField.text isEqualToString:@"男"]) {
        stringSex = @"0";
    }
    if ([_sexTextField.text isEqualToString:@"女"]) {
        stringSex = @"1";
    }
    if ([_sexTextField.text isEqualToString:@"保密"]) {
        stringSex = @"2";
    }
    NSString *nameStirng = [NSString stringWithFormat:@"%@",_userNameTextField.text];
    NSString *qqString = [NSString stringWithFormat:@"%@",_qqTextField.text];
    NSMutableDictionary *common = [NSMutableDictionary dictionaryWithCapacity:0];
    [common setObject:uidString forKey:@"uid"];
    [common setObject:stringSex forKey:@"gender"];
    [common setObject:nameStirng forKey:@"realName"];
    [common setObject:qqString forKey:@"QQ"];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@",SERVER,ACTION_UPDATEUSER];
    
    MBPHUD_SHOW;
    [DataRequest dataWithDic:common andRequestType:@"POST" andRequestCollectionAddressType:urlString andRequestSearchType:nil pageNum:1 andBlock:^(NSString *requestStr) {
        
        MBPHUD_HIDDEN;
        NSLog(@"requestStr:%@", requestStr);
        NSMutableDictionary *root= [DataRequest jsonValue:requestStr];
        NSLog(@"修改个人资料：%@", root);
        
        NSString *successString = [[root objectForKey:@"success"] stringValue];
        if ([successString isEqualToString:@"1"]) {
            //调用个人信息接口
            NSDictionary *data = [root objectForKey:@"data"];
            //删除plist
            [Util cancelLogin];
            //保存数据
            [Util setLogin:data];
            [Util setLoginOk];
            //刷新个人信息界面
            [self showMyInfoAction];
            [self.navigationController popViewControllerAnimated:YES];
            [[iToast makeToast:@"修改成功"] show];
            return;
        }
        else {
            [[iToast makeToast:@"修改失败"] show];
        }
            
    }];
}

- (IBAction)textFiledReturnEditing:(id)sender {
    [sender resignFirstResponder];
}

- (void)showMyInfoAction {
    
    NSLog(@"gender:%@",[Util getLoginData]);
    if ([[Util getLoginData] objectForKey:@"gender"]) {
        NSString *typeSex = STRING_FORMAT_INT(@"%d", [[[Util getLoginData] objectForKey:@"gender"] intValue]);
        
        if (![typeSex isEqualToString:@""]) {
            
            if ([typeSex isEqualToString:@"0"]) {
                _sexTextField.text = @"保密";
            }
            if ([typeSex isEqualToString:@"1"]) {
                _sexTextField.text = @"男";
            }
            if ([typeSex isEqualToString:@"2"]) {
                _sexTextField.text = @"女";
            }
        }
    }
    _userNameTextField.text = [[Util getLoginData] objectForKey:@"realName"];
    _AccountTextField.text =[[Util getLoginData] objectForKey:@"userName"];
    _qqTextField.text = [[Util getLoginData] objectForKey:@"QQ"];
}


@end
