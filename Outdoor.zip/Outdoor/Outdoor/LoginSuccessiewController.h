//
//  LoginSuccessiewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface LoginSuccessiewController : UIViewController <UITableViewDataSource,UITableViewDelegate, UIAlertViewDelegate>

@end
