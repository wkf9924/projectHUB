//
//  ActivityDetailViewController.h
//  Outdoor
//
//  Created by Robin on 14-2-8.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequestDelegate.h"
#import <ShareSDK/ShareSDK.h>



@interface ActivityDetailViewController : UIViewController <UIScrollViewDelegate,ASIHTTPRequestDelegate, UIAlertViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate,ISSViewDelegate,ISSShareViewDelegate>
@property (retain,nonatomic) NSString *uid;
@property (nonatomic,retain) NSString *tidString;
@property (retain, nonatomic) IBOutlet UIImageView *navImageView;
//主的scrollerView
@property (retain, nonatomic) IBOutlet UIScrollView *mainScrollView;
//主view
@property (retain, nonatomic) IBOutlet UIView *mainView;
@property (retain, nonatomic) IBOutlet UIPageControl *pageCotrol;
//滑动的图片
@property (retain, nonatomic) IBOutlet UIScrollView *scImage;
//图片详情
@property (retain, nonatomic) IBOutlet UILabel *lbInfo;
//时间
@property (retain, nonatomic) IBOutlet UILabel *lbTime;
//价格
@property (retain, nonatomic) IBOutlet UILabel *lbprice;
//人数
@property (retain, nonatomic) IBOutlet UILabel *peopleNum;
//领队
@property (retain, nonatomic) IBOutlet UILabel *lbcaptain;
@property (retain, nonatomic) IBOutlet UILabel *contentLabel;


//显示收藏和我要报名按钮的状态
@property (assign) BOOL isShowApply; //是否显示报名按钮
@property (assign) BOOL isShowCollect; //是否显示收藏
@property (assign) BOOL isShowApplyCollect; //两者都是否显示


@end
