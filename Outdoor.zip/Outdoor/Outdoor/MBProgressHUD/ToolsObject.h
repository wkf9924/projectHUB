//
//  ToolsObject.h
//  JC
//
//  Created by Tim on 11-2-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.



/*	
 文件说明：
 此文件为函数库文件，只存放函数，
 包括全局变量和全局常量的获取函数以及其他地方常用的函数集合
*/


#import <Foundation/Foundation.h>
#import <netinet/in.h>
#import <SystemConfiguration/SCNetworkReachability.h>
#import <QuartzCore/QuartzCore.h>
#import "UIWindowAdditions.h"

@interface ToolsObject : NSObject {

}

//错误提示
+(void)ErrorAlert:(NSString*)errorMsg withTitle:(NSString*)titleMsg;

//转换时间格式，精确到分钟
+ (NSString*)convertTimeStyleToMin:(id)timeStr;
+ (NSString*)convert2String:(id)timeStr ;

//图片缩放
+(UIImage*)scaleToSize:(CGSize)size withImg:(UIImage*)img;
// 判断该email是否合法
//+(BOOL)isisMatchedEmail:(NSString *)str;

//将图片变成圆角
+ (id) createRoundedRectImage:(UIImage*)image;

//等比例缩放  
+(UIImage*)scaleImage:(UIImage*)image toSize:(CGSize)size;
//裁剪图片
+(UIImage *)subImageFromImage:(UIImage*) superImage subImageRect:(CGRect)subImageRect;
//键盘是否开启
+(BOOL)TTIsKeyboardVisible;

//判断jpeg图片是否完整
+(BOOL)isJPEGValid:(NSData*)data;
//判断png图片是否完整
+(BOOL)isPNGValid:(NSData *)data;
+ (BOOL)isJPG:(NSData *)data;
+ (BOOL)isPNG:(NSData *)data;
@end

