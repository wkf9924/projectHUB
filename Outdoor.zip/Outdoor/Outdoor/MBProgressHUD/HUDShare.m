//
//  HUDShare.m
//  ElecMenu
//
//  Created by zhou yehong on 12-5-24.
//  Copyright (c) 2012年 273337171@qq.com. All rights reserved.

#import "HUDShare.h"
#import "Api.h"
#import "ToolsObject.h"

#define HUD_DELAY 1.5
#define HUD_DELAY_TEXT 3
@interface HUDShare(private)
-(void)showComplete:(NSString*)text imageName:(NSString*)imgname;
@end
@implementation HUDShare
@synthesize HUD;
static HUDShare *hudShare;
+(HUDShare*) shareInstance {
    if (!hudShare) {
        @synchronized(self){
            hudShare = [HUDShare new];
        }
    }
    return hudShare;
}

- (void)showText:(NSString*)text{

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:THE_KEY_WINDOWN animated:YES];
	// Configure for text only and offset down
	hud.mode = MBProgressHUDModeText;
	hud.labelText = text;
	hud.margin = 10.f;
    if (![ToolsObject TTIsKeyboardVisible]) {
        hud.yOffset = 150.f;
    } else {
        hud.yOffset = -100.f;
    }
	hud.removeFromSuperViewOnHide = YES;
	hud.userInteractionEnabled = NO;
	[hud hide:YES afterDelay:HUD_DELAY_TEXT];
}

-(void)showWait:(NSString*)text{
    
    [self showWait:text toView:THE_KEY_WINDOWN];
}

-(void)showWait:(NSString*)text toView:(UIView*)view{
    if (HUD) {
        [HUD removeFromSuperview];
        HUD.delegate = nil;
        self.HUD = nil;
    }
    self.HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    HUD.delegate = self;
    if ([ToolsObject TTIsKeyboardVisible]) {
        HUD.yOffset = -100.f;
    }
    HUD.labelText = text;
    [HUD show:YES];
    [[HUD superview] bringSubviewToFront:HUD];
}

-(void)hideWait{
    [HUD hide:YES];
}

-(void)showComplete:(NSString*)text{
    [self showComplete:text imageName:@"37x-Checkmark.png"];
}

-(void)showFail:(NSString*)text{
    [self showComplete:text imageName:@"37x-Error.png"];
}

-(void)showComplete:(NSString*)text imageName:(NSString*)imgname{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:THE_KEY_WINDOWN animated:YES];
	hud.mode = MBProgressHUDModeCustomView;
    hud.customView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:imgname]] autorelease];
	hud.labelText = text;
    hud.userInteractionEnabled = NO;
    //hud.square = YES;
	hud.removeFromSuperViewOnHide = YES;
	[hud hide:YES afterDelay:HUD_DELAY];
}

- (void)showWhileExecuted:(NSString*)text sel:(SEL)selecoter target:(id)t withObject:(id)w {
	HUD = [[MBProgressHUD alloc] initWithView:THE_KEY_WINDOWN];
	[THE_KEY_WINDOWN addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = text;
	HUD.square = YES;
	[HUD showWhileExecuting:selecoter onTarget:t withObject:w animated:YES];
}

#pragma mark MBProgressHUDDelegate methods
- (void)hudWasHidden:(MBProgressHUD *)hud {
	[HUD removeFromSuperview];
    HUD.delegate = nil;
	self.HUD = nil;
    NSLog(@"hidden");
}

#pragma mark - sengleton setting
+ (id)allocWithZone:(NSZone *)zone 
{
    @synchronized(self) 
    {
        if (!hudShare) 
        {
            hudShare = [super allocWithZone:zone];
        }
    }
    return hudShare;
}

+ (id)copyWithZone:(NSZone *)zone 
{
    return self;
}

- (id)retain 
{
    return self;
}

- (unsigned)retainCount 
{
    return UINT_MAX;
}

- (oneway void)release 
{
    
}

- (id)autorelease 
{
    return self;
}


@end
