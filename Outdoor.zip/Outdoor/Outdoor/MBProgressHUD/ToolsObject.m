//
//  ToolsObject.m
//  JC
//
//  Created by Tim on 11-2-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ToolsObject.h"

@implementation ToolsObject

#pragma mark -
#pragma mark 错误提示
/*
 此函数为错误提示框，用于各种错误提示消息
 */

+(void)ErrorAlert:(NSString*)errorMsg withTitle:(NSString*)titleMsg;
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titleMsg 
													message:errorMsg
												   delegate:nil
										  cancelButtonTitle:@"确定"
										  otherButtonTitles:nil];
	[alert show];
	[alert release];
}


#pragma mark -
#pragma mark 时间转换函数模块
/*
 此函数模块用于转换时间戳为格式化时间
 
 输入参数：1970自今的秒数时间戳
 输出参数：格式化的时间字符串
 错误处理：如果传入时间戳为空，返回空字符串
 */


//转换时间格式，精确到分钟  -use
+ (NSString*)convertTimeStyleToMin:(id)timeStr 
{			
	if (timeStr) {
//        NSLog(@"time:%@",timeStr);
        NSDate *date=nil;
        if ([timeStr isKindOfClass:[NSDate class]]) {
            date = timeStr;
        } else {
            date=[NSDate dateWithTimeIntervalSince1970:[timeStr doubleValue]/1000];
        }
//        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *comps = [[[NSDateComponents alloc] init] autorelease];
        NSInteger unitFlags = NSYearCalendarUnit ;//| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | 
        //NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
     
        comps = [calendar components:unitFlags fromDate:[NSDate date]];
        int nowyear = [comps year];
        comps = [calendar components:unitFlags fromDate:date];
        int year = [comps year];
//        [comps release];
//        [calendar release];
        
        NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
        if (nowyear == year) {
            [formatter setDateFormat:@"MM-dd HH:mm"];
        } else {
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
        }
        
//        int nowyear=[[[NSDate date] dateWithCalendarFormat:nil timeZone:nil] yearOfCommonEra];
		NSString* timeString = [formatter stringFromDate:date];
        
		[formatter release];
		return timeString;
	}
	else {
		NSLog(@"传入时间戳为空");
		return @"";
	}
	
}
//转换时间格式 -use
+ (NSString*)convert2String:(id)timeStr 
{			
	if (timeStr) {
        NSDate *date;
        if ([timeStr isKindOfClass:[NSDate class]]) {
            date = timeStr;
        } else {
            if ([timeStr isKindOfClass:[NSString class]]) {
                if ([timeStr isEqualToString:@""]) {
                    return @"";
                } else if([timeStr rangeOfString:@"-"].location != NSNotFound){
                    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
                    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                    date = [formatter dateFromString:timeStr];
                    [formatter release];
                }
            }else
                date=[NSDate dateWithTimeIntervalSince1970:[timeStr doubleValue]/1000];
        }
//        NSLog(@"date string:%@",[ToolsObject convertTimeStyleToMin:timeStr]);
//        NSLog(@"date:%@",date);
        double now=[[NSDate date] timeIntervalSinceDate:date]/60.0f;
//        
//        double distTime = now - ctime;
//        NSLog(@"分钟:%f",now);
        if (now<1) {
//            NSLog(@"小于一分钟:%f",now);
            return @"刚刚";
       } else if (now < 60) {
//            NSLog(@"多少分钟前:%f",now);
            return [NSString stringWithFormat:@"%d分钟前",(int)now];
        }else {
            now /= 60;
//            NSLog(@"小时:%f",now);
            if (now < 24) {
//                NSLog(@"多少小时前:%f",now);
                return [NSString stringWithFormat:@"%d小时前",(int)now];
            } else {
                return [ToolsObject convertTimeStyleToMin:date];
            }
        }
	}
	else {
		NSLog(@"传入时间戳为空");
		return @"";
	}
	
}

#pragma mark -
#pragma mark 图片处理模块
/*
 此函数用于图片缩放
 输入参数：(CGSize)需要缩放的尺寸,(UIImage*)需要缩放的图片对象
 输出参数：缩放后的图片
 */

+(UIImage*)scaleToSize:(CGSize)size withImg:(UIImage*)img
{  
    // 创建一个bitmap的context  
    // 并把它设置成为当前正在使用的context  
    UIGraphicsBeginImageContext(size);  
    // 绘制改变大小的图片  
    [img drawInRect:CGRectMake(0, 0, size.width, size.height)];  
    // 从当前context中创建一个改变大小后的图片  
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();  
    // 使当前的context出堆栈  
    UIGraphicsEndImageContext();  
    // 返回新的改变大小后的图片  
    return scaledImage;  
}

/*
 图片修改成圆角的view
 注：需要导入QuartzCore框架 导入头文件#import <QuartzCore/QuartzCore.h>
 输入参数：需要改变的view
 输出参数：经过圆角处理的view
 */
+(UIView *)getRoundView:(UIView *)aView
{
	//圆角 边框的宽度 
 	aView.layer.borderWidth = 1.0f;
	//是否允许弯曲
 	aView.layer.masksToBounds=YES;
	//要弯的弧度
 	aView.layer.cornerRadius=5;
	//边框的颜色 
 	aView.layer.borderColor = [[UIColor clearColor] CGColor];
	return aView;
}

//设置个边框并且给个颜色
+(UIView *)setButtnBorderColor:(UIView *)aView viewColor:(UIColor *)color
{
	
 	[aView.layer setMasksToBounds:YES];
	aView.clipsToBounds = YES;
	//圆角 边框的宽度 
 	aView.layer.borderWidth = 2;
	//是否允许弯曲
 	aView.layer.masksToBounds=NO;
	//要弯的弧度
 	aView.layer.cornerRadius=8.0;
	//边框的颜色 
 	aView.layer.borderColor = [color CGColor];
	return aView;
}

//返回一个阴影的view
+(UIView *)getShadowView:(UIView *)aView
{
     //UIView设置阴影
    [[aView layer] setShadowOffset:CGSizeMake(1, 1)];
    [[aView layer] setShadowRadius:5];
    [[aView layer] setShadowOpacity:2];
    [[aView layer] setShadowColor:[UIColor blackColor].CGColor];
    //UIView设置边框
    [[aView layer] setCornerRadius:5];
    [[aView layer] setBorderWidth:2];
    [[aView layer] setBorderColor:[UIColor whiteColor].CGColor];
	return aView;
}


static void addRoundedRectToPath(CGContextRef context, CGRect rect, float ovalWidth,
                                 float ovalHeight)
{
    float fw, fh;
    if (ovalWidth == 0 || ovalHeight == 0) {
        CGContextAddRect(context, rect);
        return;
    }
    
    CGContextSaveGState(context);
    CGContextTranslateCTM(context, CGRectGetMinX(rect), CGRectGetMinY(rect));
    CGContextScaleCTM(context, ovalWidth, ovalHeight);
    fw = CGRectGetWidth(rect) / ovalWidth;
    fh = CGRectGetHeight(rect) / ovalHeight;
    
    CGContextMoveToPoint(context, fw, fh/2);  // Start at lower right corner
    CGContextAddArcToPoint(context, fw, fh, fw/2, fh, 1);  // Top right corner
    CGContextAddArcToPoint(context, 0, fh, 0, fh/2, 1); // Top left corner
    CGContextAddArcToPoint(context, 0, 0, fw/2, 0, 1); // Lower left corner
    CGContextAddArcToPoint(context, fw, 0, fw, fh/2, 1); // Back to lower right
    
    CGContextClosePath(context);
    CGContextRestoreGState(context);
}
//将图片变成圆角
+ (id) createRoundedRectImage:(UIImage*)image
{
    int w = image.size.width;
    int h = image.size.height;
    
    UIImage *img = image;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL, w, h, 8, 4 * w, colorSpace, kCGImageAlphaPremultipliedFirst);
    CGRect rect = CGRectMake(0, 0, w, h);
    
    CGContextBeginPath(context);
    addRoundedRectToPath(context, rect, 5, 5);
    CGContextClosePath(context);
    CGContextClip(context);
    CGContextDrawImage(context, CGRectMake(0, 0, w, h), img.CGImage);
    CGImageRef imageMasked = CGBitmapContextCreateImage(context);

    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    if (!imageMasked) {
        CFRelease(imageMasked);
        return nil;
    }
    UIImage *_img = [UIImage imageWithCGImage:imageMasked];
    CFRelease(imageMasked);
    return _img;
}

//等比例缩放
+(UIImage*)scaleImage:(UIImage*)image toSize:(CGSize)size{

    int h = image.size.height;
    int w = image.size.width;
    if(w <= size.width && h <= size.height)
    {
        return image;
    }
    else 
    {
        float b = (float)size.width/w < (float)size.height/h ? (float)size.width/w : (float)size.height/h;
        CGSize itemSize = CGSizeMake(b*w, b*h);
        UIGraphicsBeginImageContext(itemSize);
        CGRect imageRect = CGRectMake(0, 0, b*w, b*h);
        [image drawInRect:imageRect];
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    return image;

}

//裁剪图片
+(UIImage *)subImageFromImage:(UIImage*) superImage subImageRect:(CGRect)subImageRect
{
    CGImageRef img=CGImageCreateWithImageInRect(superImage.CGImage,subImageRect);
    return [UIImage imageWithCGImage:img];
}

//键盘是否开启
+(BOOL)TTIsKeyboardVisible{
    // Operates on the assumption that the keyboard is visible if and only if there is a first
    // responder; i.e. a control responding to key events
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    return !![window findFirstResponder];
}

//判断jpeg图片是否完整
+(BOOL)isJPEGValid:(NSData *)data
{
    if (![ToolsObject isJPG:data]) {
        return YES;
    }
    if (!data || data.length < 2) return NO;
    
    NSInteger totalBytes = data.length;
    const char *bytes = (const char*)[data bytes];
    
    return (//bytes[0] == (char)0xff && 
            //bytes[1] == (char)0xd8 &&
            bytes[totalBytes-2] == (char)0xff &&
            bytes[totalBytes-1] == (char)0xd9);
}
//判断png图片是否完整
+(BOOL)isPNGValid:(NSData *)data
{
    if (![ToolsObject isPNG:data]) {
        return YES;
    }
    if (!data || data.length < 2) return NO;
    
    unsigned char buffer[4];
    NSRange rang;
    rang.length = 2;
    rang.location = data.length - 2;
    [data getBytes:&buffer range:rang];
    NSLog(@"%d,%d",buffer[0],buffer[1]);//96,130
    return YES;
}
//http://www.astro.keele.ac.uk/oldusers/rno/Computing/File_magic.html
+ (BOOL)isJPG:(NSData *)data
{
    if (data.length > 4)
    {
        unsigned char buffer[4];
        [data getBytes:&buffer length:4];
        
        return buffer[0]==0xff && 
        buffer[1]==0xd8; //&& 
        //buffer[2]==0xff &&
        //buffer[3]==0xe0;
    }
    
    return NO;
}

+ (BOOL)isPNG:(NSData *)data
{
    if (data.length > 4)
    {
        unsigned char buffer[4];
        [data getBytes:&buffer length:4];
        
        return buffer[0]==0x89 &&
        buffer[1]==0x50 &&
        buffer[2]==0x4e &&
        buffer[3]==0x47;
    }
    return NO;
}

@end


