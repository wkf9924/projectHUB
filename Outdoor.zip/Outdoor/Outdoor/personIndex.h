//
//  personIndex.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-6.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface personIndex : NSObject
@property (strong, nonatomic) NSArray *personArr;
@property (strong, nonatomic) NSMutableArray *personMulArr;

//清空原有数据
-(void) deletePlist;
//响应错误
-(void) showAlert:(NSString *)stringData;
//获取远端数据
-(void) getRemoteData;
//创建plist文件
-(void) createPlist;
//写入数据到plist文件
-(void) writePlist;
//解析json数据
-(NSArray *) readJsonData:(NSMutableData *)data;
//下载数据
-(void) executeDown;

@end
