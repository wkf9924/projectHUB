//
//  MessageApplyVC.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-20.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface MessageApplyVC : UIViewController <UITableViewDataSource,UITableViewDelegate>

@end
