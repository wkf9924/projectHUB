//
//  CollectViewController.h
//  Outdoor
//
//  Created by Robin on 14-2-13.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequestDelegate.h"
#import "EGORefreshTableHeaderDelegate.h"
#import "Api.h"
@interface CollectViewController : UIViewController <UITableViewDelegate,UITableViewDataSource, ASIHTTPRequestDelegate, EGORefreshTableHeaderDelegate>

@end
