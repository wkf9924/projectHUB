//
//  ImageCell.h
//  Outdoor
//
//  Created by Robin on 14-1-25.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"
#import "UIDataButton.h"
@interface ImageCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *imageAA;
@property (retain, nonatomic) IBOutlet UIImageView *imagePrice;
@property (retain, nonatomic) IBOutlet EGOImageView *imageViewbg;
@property (retain, nonatomic) IBOutlet UILabel *price;
@property (retain, nonatomic) IBOutlet UILabel *timeLabel;
@property (retain, nonatomic) IBOutlet UILabel *titleLab;
@property (retain, nonatomic) IBOutlet UIImageView *timeImageView;
@property (retain, nonatomic) IBOutlet UIDataButton *buttonData;
@property (retain, nonatomic) IBOutlet UILabel *categoryLab;
@property (retain, nonatomic) IBOutlet UILabel *residueNumberLab;

@end
