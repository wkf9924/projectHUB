//
//  RecordCell.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titleLab;
@property (retain, nonatomic) IBOutlet UILabel *dateLab;
@property (retain, nonatomic) IBOutlet UILabel *userLab;
@property (retain, nonatomic) IBOutlet UILabel *addLab;

@end
