//
//  MyMessageViewController.h
//  Outdoor
//
//  Created by WangKaifeng on 14-2-17.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

@interface MyMessageViewController : UIViewController

- (IBAction)back:(id)sender;
@end
