//
//  ImageCellTwo.h
//  Outdoor
//
//  Created by WangKaifeng on 14-3-21.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"
#import "UIDataButton.h"
@interface ImageCellTwo : UITableViewCell

@property (retain, nonatomic) IBOutlet EGOImageView  *imageViewLeft;
@property (retain, nonatomic) IBOutlet UILabel *timeLeft;
@property (retain, nonatomic) IBOutlet UILabel *prictLeft;
@property (retain, nonatomic) IBOutlet UILabel *titleLeft;

@property (retain, nonatomic) IBOutlet UILabel *timeRight;
@property (retain, nonatomic) IBOutlet UILabel *priceRight;
@property (retain, nonatomic) IBOutlet EGOImageView *imageViewRight;
@property (retain, nonatomic) IBOutlet UILabel *titleRight;
@property (retain, nonatomic) IBOutlet UIImageView *frameImageView; //边框
@property (retain, nonatomic) IBOutlet UIImageView *defaultImage;
@property (retain, nonatomic) IBOutlet UIImageView *timeItemImage;
@property (retain, nonatomic) IBOutlet UIImageView *timeImage;
@property (retain, nonatomic) IBOutlet UIImageView *priceImage;
@property (retain, nonatomic) IBOutlet UIDataButton *btn_left;
@property (retain, nonatomic) IBOutlet UIDataButton *btn_right;
@property (retain, nonatomic) IBOutlet UILabel *labBotton;  //文字底色label

@property (retain, nonatomic) IBOutlet UILabel *applyLabel;
@property (retain, nonatomic) IBOutlet UILabel *applyRightLabel;

@property (retain, nonatomic) IBOutlet UIView *leftView;

@property (retain, nonatomic) IBOutlet UIView *rightView;

@property (retain, nonatomic) IBOutlet UILabel *categoryLeft;

@property (retain, nonatomic) IBOutlet UILabel *categoryRight;


@end
