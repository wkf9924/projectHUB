//
//  CollectCell.h
//  Outdoor
//
//  Created by Robin on 14-2-13.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titleCollect;

@property (retain, nonatomic) IBOutlet UILabel *timeLabel;
@property (retain, nonatomic) IBOutlet UILabel *priceLabel;
@end
