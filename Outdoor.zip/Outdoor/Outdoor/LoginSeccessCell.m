//
//  LoginSeccessCell.m
//  Outdoor
//
//  Created by WangKaifeng on 14-2-15.
//  Copyright (c) 2014年 Robin. All rights reserved.
//

#import "LoginSeccessCell.h"

@implementation LoginSeccessCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_titleString release];
    [_cellImageView release];
    [_moreButton release];
    [super dealloc];
}
@end
